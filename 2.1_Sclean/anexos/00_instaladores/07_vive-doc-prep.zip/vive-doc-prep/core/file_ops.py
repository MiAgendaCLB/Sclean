"""
Fase 7 — Operación de archivo.

Reglas de seguridad ya fijadas en la especificación funcional:
- Idempotencia: si el destino ya existe con el nombre final exacto, no se
  repite la operación (se registra 'ya_existia', no error).
- Modo prueba (dry-run) por defecto en toda acción destructiva.
- Cada operación queda registrada en log_operaciones, con resumen final
  verificable por lote.

Este módulo solo mueve/renombra hacia LISTOS_PARA_IMPORTAR o NO_PROCESADOS;
no borra nada (el borrado, si llega a implementarse, es una operación
distinta y seguiría el mismo principio de dry-run por defecto).
"""

from __future__ import annotations

import shutil
import sqlite3
from pathlib import Path


class OperacionFallida(Exception):
    pass


def mover_a_listos_para_importar(
    conn: sqlite3.Connection,
    documento_id: int,
    carpeta_salida: str,
    dry_run: bool = False,
) -> str:
    """
    Mueve el documento (ya con nombre_propuesto definido en la Fase 6) a la
    carpeta de Listos_para_importar, de forma idempotente.

    Devuelve la ruta final del archivo (real o simulada, si dry_run=True).
    """
    fila = conn.execute(
        "SELECT ruta_original, ruta_segmento, nombre_propuesto, estado_proceso FROM documentos WHERE id = ?",
        (documento_id,),
    ).fetchone()
    if fila is None:
        raise OperacionFallida(f"No existe el documento {documento_id}")

    ruta_original, ruta_segmento, nombre_propuesto, estado_proceso = fila
    # Se copia el PDF ya recortado a las páginas de este grupo (ruta_segmento).
    # Copiar ruta_original copiaría el archivo de entrada completo, con todas
    # las páginas del lote, no solo las que corresponden a este documento —
    # el bug real detectado con un documento de prueba (HC y OS generados
    # con el nombre correcto, pero ambos con las 5 páginas completas).
    ruta_fuente = ruta_segmento or ruta_original
    if not nombre_propuesto:
        raise OperacionFallida(
            f"El documento {documento_id} no tiene nombre_propuesto; "
            f"debe pasar primero por la Fase 6 (nomenclatura)."
        )

    destino = Path(carpeta_salida) / nombre_propuesto

    # Idempotencia primero: si el destino ya existe, no importa si esta
    # ejecución es un reproceso posterior a una exportación exitosa anterior
    # (estado_proceso ya sería 'Exportado', no 'Clasificado'). Solo se exige
    # la confirmación humana previa cuando se va a realizar un movimiento
    # nuevo de verdad.
    if destino.exists():
        _log(conn, documento_id, "mover_archivo", "ya_existia", str(destino))
        return str(destino)

    if estado_proceso != "Clasificado":
        raise OperacionFallida(
            f"El documento {documento_id} no está confirmado (estado_proceso={estado_proceso}); "
            f"no se mueve sin confirmación humana previa."
        )

    if dry_run:
        _log(conn, documento_id, "mover_archivo", "simulado", f"destino propuesto: {destino}")
        return str(destino)

    destino.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(ruta_fuente, destino)
    except OSError as exc:
        _log(conn, documento_id, "mover_archivo", "error", str(exc))
        raise OperacionFallida(f"No se pudo copiar el archivo: {exc}") from exc

    conn.execute(
        "UPDATE documentos SET ruta_actual = ?, estado = 'LISTO_PARA_IMPORTAR', estado_proceso = 'Exportado' WHERE id = ?",
        (str(destino), documento_id),
    )
    _log(conn, documento_id, "mover_archivo", "movido", str(destino))
    conn.commit()
    return str(destino)


def _log(conn: sqlite3.Connection, documento_id: int, accion: str, resultado: str, detalle: str) -> None:
    conn.execute(
        "INSERT INTO log_operaciones (documento_id, accion, resultado, detalle) VALUES (?, ?, ?, ?)",
        (documento_id, accion, resultado, detalle),
    )
    conn.commit()


def resumen_lote(conn: sqlite3.Connection, documento_ids: list[int]) -> dict:
    """
    Resumen final verificable por lote: si el log no llega hasta aquí, algo
    se cortó a medio camino (regla ya fijada en la especificación).
    """
    placeholders = ",".join("?" for _ in documento_ids)
    filas = conn.execute(
        f"""
        SELECT accion, resultado, COUNT(*) FROM log_operaciones
        WHERE documento_id IN ({placeholders}) AND accion = 'mover_archivo'
        GROUP BY accion, resultado
        """,
        documento_ids,
    ).fetchall()
    resumen = {resultado: cantidad for _, resultado, cantidad in filas}
    resumen["total_lote"] = len(documento_ids)
    return resumen
