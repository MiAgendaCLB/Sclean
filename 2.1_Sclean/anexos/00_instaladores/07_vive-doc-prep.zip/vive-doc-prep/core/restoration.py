"""
Fase 9 — Restauración condicional (módulo opcional).

Ya decidido en la arquitectura: la restauración de imagen NO corre por
defecto. De los 4 documentos reales usados en todas las pruebas de este
proyecto, ninguno la necesitó (todos tenían calidad de escaneo/impresión
suficiente para OCR directo). Este módulo existe para el caso en que
aparezca un documento realmente degradado, y se activa explícitamente,
nunca de forma automática.

Regla ya fijada: si la página ya tiene buena calidad, no se toca. La
intensidad de corrección se decide por página, no de forma global sobre
todo el documento.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
import ocrmypdf
from pdf2image import convert_from_path

# Umbral de nitidez (varianza del laplaciano). Por debajo de esto, se
# considera que la página se beneficiaría de restauración. Calibrado de
# forma conservadora: mejor no tocar una página dudosa que degradar una
# página que ya estaba bien.
UMBRAL_NITIDEZ = 100.0


@dataclass
class AnalisisCalidad:
    numero_pagina: int
    nitidez: float
    necesita_restauracion: bool


def analizar_calidad(ruta_pdf: str) -> list[AnalisisCalidad]:
    """
    Analiza cada página del PDF y determina si amerita restauración.
    No modifica nada; solo diagnostica.
    """
    imagenes = convert_from_path(ruta_pdf, dpi=150)
    resultados = []
    for i, imagen in enumerate(imagenes, start=1):
        arreglo = np.array(imagen.convert("L"))  # escala de grises
        nitidez = cv2.Laplacian(arreglo, cv2.CV_64F).var()
        resultados.append(
            AnalisisCalidad(
                numero_pagina=i,
                nitidez=nitidez,
                necesita_restauracion=nitidez < UMBRAL_NITIDEZ,
            )
        )
    return resultados


def restaurar_si_necesario(ruta_entrada: str, ruta_salida: str) -> tuple[str, list[AnalisisCalidad]]:
    """
    Aplica corrección solo a las páginas que lo necesitan (deskew + mejora de
    contraste vía Ghostscript/qpdf ya cubierto por OCRmyPDF con
    --clean --deskew; este módulo se activa ANTES de OCRmyPDF cuando el
    análisis de calidad lo justifica).

    Si ninguna página lo necesita, ruta_salida = ruta_entrada (no se genera
    un archivo nuevo innecesariamente, evitando trabajo y riesgo sin
    beneficio real).
    """
    analisis = analizar_calidad(ruta_entrada)
    if not any(a.necesita_restauracion for a in analisis):
        return ruta_entrada, analisis

    Path(ruta_salida).parent.mkdir(parents=True, exist_ok=True)
    try:
        ocrmypdf.ocr(ruta_entrada, ruta_salida, clean=True, deskew=True, skip_text=True, progress_bar=False)
    except Exception:
        # Si la restauración falla, se conserva el original sin alterar,
        # nunca se entrega un archivo a medio procesar.
        return ruta_entrada, analisis

    return ruta_salida, analisis
