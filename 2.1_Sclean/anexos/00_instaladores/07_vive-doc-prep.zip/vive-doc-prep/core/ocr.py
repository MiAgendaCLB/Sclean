"""
Fase 1 — OCR de refuerzo.

Ejecuta OCRmyPDF con --skip-text: las páginas que ya tienen una capa de texto
nativa se dejan intactas, y solo se aplica OCR a las páginas que no la tienen.

Se usa la API de Python de OCRmyPDF (no el comando de línea) para que
PyInstaller lo empaquete como una dependencia normal del código, junto con
todo lo que ocrmypdf necesita en Python. Solo Tesseract, Ghostscript y qpdf
siguen siendo binarios externos genuinos (no son paquetes de Python) y se
empaquetan aparte (ver build_scripts/empaquetar.py), localizándolos vía PATH
en tiempo de ejecución.

El resultado es siempre un PDF nuevo (nunca se sobreescribe el original) con
texto oculto embebido, listo para que text_extraction.py lea el texto de
cada página.
"""

from __future__ import annotations

from pathlib import Path

import ocrmypdf


class ErrorOCR(Exception):
    pass


def aplicar_ocr(ruta_entrada: str, ruta_salida: str, idioma: str = "spa") -> str:
    """
    Ejecuta OCRmyPDF sobre ruta_entrada y escribe el resultado en ruta_salida.
    Devuelve ruta_salida si tiene éxito. Lanza ErrorOCR si falla.
    """
    Path(ruta_salida).parent.mkdir(parents=True, exist_ok=True)

    try:
        ocrmypdf.ocr(ruta_entrada, ruta_salida, skip_text=True, language=idioma, progress_bar=False)
    except Exception as exc:  # noqa: BLE001 - cualquier fallo de OCRmyPDF se reporta igual
        raise ErrorOCR(f"OCRmyPDF falló sobre {ruta_entrada}: {exc}") from exc

    return ruta_salida
