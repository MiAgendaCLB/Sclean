"""
Fase 3 — Segmentación.

Con la clasificación de cada página ya resuelta (Fase 2), agrupa las páginas
contiguas que comparten sigla en un solo sub-documento.

Regla de herencia (detectada durante las pruebas de la Fase 2, no estaba en
el motor de clasificación por diseño): una página sin resolver que queda
entre dos páginas de la misma sigla ya confirmada hereda sus metadatos
(entidad, miembro, especialidad/asunto). Esto no es adivinar contenido: es
reconocer que una página de continuación (sin encabezado ni nombre de
paciente repetido) pertenece al mismo documento físico que la rodea.

Si una página sin resolver no está entre dos páginas de la misma sigla
(por ejemplo, al inicio o al final de un lote, o rodeada de siglas
distintas), NO se le asigna nada por adivinanza: queda fuera de cualquier
grupo y su sub-documento resultante va a NO_PROCESADO, tal como exige la
especificación funcional.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from core.classification.engine import ClasificacionPagina


@dataclass
class GrupoDocumento:
    paginas: list[int] = field(default_factory=list)
    sigla_id: int | None = None
    sigla_codigo: str | None = None
    especialidad_asunto: str | None = None
    entidad_id: int | None = None
    miembro_id: int | None = None
    resuelto: bool = False  # False -> el grupo completo va a NO_PROCESADO


def segmentar(clasificaciones: list[ClasificacionPagina]) -> list[GrupoDocumento]:
    """
    Recibe las clasificaciones en orden de página (1..N) y devuelve la lista
    de sub-documentos resultantes, ya con la herencia aplicada.
    """
    enriquecidas = _aplicar_herencia(clasificaciones)
    return _agrupar_por_sigla_contigua(enriquecidas)


def _aplicar_herencia(clasificaciones: list[ClasificacionPagina]) -> list[ClasificacionPagina]:
    resultado = list(clasificaciones)
    n = len(resultado)

    # Paso A: páginas que ya tienen su propia sigla detectada (solo les falta
    # entidad/miembro) heredan del vecino inmediato resuelto con la misma sigla.
    # Se procesa en orden, así que una cadena de varias páginas del mismo tipo
    # se resuelve en cascada de izquierda a derecha.
    for i in range(n):
        pagina = resultado[i]
        if pagina.resuelta or pagina.sigla_id is None:
            continue
        anterior = resultado[i - 1] if i > 0 else None
        siguiente = resultado[i + 1] if i + 1 < n else None
        candidato = None
        if anterior and anterior.resuelta and anterior.sigla_id == pagina.sigla_id:
            candidato = anterior
        elif siguiente and siguiente.resuelta and siguiente.sigla_id == pagina.sigla_id:
            candidato = siguiente
        if candidato is not None:
            resultado[i] = _heredar(pagina, candidato)

    # Paso B: páginas sin sigla propia -> se identifica el bloque completo de
    # páginas consecutivas sin resolver, y solo se rellena entero si la página
    # resuelta justo antes y la de justo después coinciden en sigla (o si el
    # bloque está en un extremo del lote, con un solo vecino resuelto).
    i = 0
    while i < n:
        if resultado[i].resuelta or resultado[i].sigla_id is not None:
            i += 1
            continue
        inicio = i
        while i < n and not resultado[i].resuelta and resultado[i].sigla_id is None:
            i += 1
        fin = i  # exclusivo

        anterior = resultado[inicio - 1] if inicio > 0 else None
        siguiente = resultado[fin] if fin < n else None
        candidato = None
        if anterior and anterior.resuelta and siguiente and siguiente.resuelta:
            if anterior.sigla_id == siguiente.sigla_id:
                candidato = anterior
        elif anterior and anterior.resuelta and siguiente is None:
            candidato = anterior
        elif siguiente and siguiente.resuelta and anterior is None:
            candidato = siguiente

        if candidato is not None:
            for j in range(inicio, fin):
                resultado[j] = _heredar(resultado[j], candidato)

    return resultado


def _heredar(pagina: ClasificacionPagina, candidato: ClasificacionPagina) -> ClasificacionPagina:
    return ClasificacionPagina(
        numero_pagina=pagina.numero_pagina,
        sigla_id=candidato.sigla_id,
        sigla_codigo=candidato.sigla_codigo,
        especialidad_asunto=candidato.especialidad_asunto,
        entidad_id=candidato.entidad_id,
        miembro_id=candidato.miembro_id,
        resuelta=True,
    )


def _agrupar_por_sigla_contigua(clasificaciones: list[ClasificacionPagina]) -> list[GrupoDocumento]:
    grupos: list[GrupoDocumento] = []
    grupo_actual: GrupoDocumento | None = None

    for pagina in clasificaciones:
        mismo_grupo = (
            grupo_actual is not None
            and grupo_actual.resuelto
            and pagina.resuelta
            and pagina.sigla_id == grupo_actual.sigla_id
            and pagina.entidad_id == grupo_actual.entidad_id
            and pagina.miembro_id == grupo_actual.miembro_id
        )

        if mismo_grupo:
            grupo_actual.paginas.append(pagina.numero_pagina)
            continue

        grupo_actual = GrupoDocumento(
            paginas=[pagina.numero_pagina],
            sigla_id=pagina.sigla_id,
            sigla_codigo=pagina.sigla_codigo,
            especialidad_asunto=pagina.especialidad_asunto,
            entidad_id=pagina.entidad_id,
            miembro_id=pagina.miembro_id,
            resuelto=pagina.resuelta,
        )
        grupos.append(grupo_actual)

    return grupos
