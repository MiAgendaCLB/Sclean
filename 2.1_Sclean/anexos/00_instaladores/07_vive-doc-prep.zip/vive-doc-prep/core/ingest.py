"""
Fase 1 — Ingesta.

Valida que el PDF de entrada se puede abrir correctamente y calcula su hash.

Decisión de implementación (no cambia el modelo de datos congelado):
no se inserta en `documentos` todavía si el archivo es válido, porque el
estado real (clasificado o NO_PROCESADO) solo se conoce más adelante en el
pipeline, y el modelo de estados ya congelado no contempla un estado
intermedio de "en proceso". Solo el caso de archivo corrupto se registra
aquí mismo, porque su estado final (NO_PROCESADO) ya se conoce sin necesidad
de más pasos.
"""

from __future__ import annotations

import hashlib
import sqlite3
from dataclasses import dataclass
from pathlib import Path

import pikepdf


@dataclass
class DocumentoValidado:
    ruta_original: str
    nombre_original: str
    hash: str
    num_paginas: int


def _calcular_hash(ruta: Path) -> str:
    sha256 = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(65536), b""):
            sha256.update(bloque)
    return sha256.hexdigest()


def validar_pdf(ruta: str, conn: sqlite3.Connection) -> DocumentoValidado | None:
    """
    Intenta abrir el PDF con pikepdf.
    - Si falla: registra el documento como NO_PROCESADO con el motivo en el
      log de operaciones y devuelve None (no continúa en el pipeline).
    - Si abre correctamente: devuelve sus datos básicos sin tocar la base de
      datos todavía.
    """
    ruta_path = Path(ruta)
    nombre_original = ruta_path.name

    try:
        with pikepdf.open(ruta_path) as pdf:
            num_paginas = len(pdf.pages)
    except Exception as exc:  # noqa: BLE001 - cualquier fallo de apertura es "corrupto" a estos efectos
        _registrar_archivo_corrupto(conn, str(ruta_path), nombre_original, str(exc))
        return None

    return DocumentoValidado(
        ruta_original=str(ruta_path),
        nombre_original=nombre_original,
        hash=_calcular_hash(ruta_path),
        num_paginas=num_paginas,
    )


def _registrar_archivo_corrupto(
    conn: sqlite3.Connection, ruta: str, nombre_original: str, motivo: str
) -> int:
    cur = conn.execute(
        """
        INSERT INTO documentos (ruta_original, nombre_original, estado, estado_proceso)
        VALUES (?, ?, 'NO_PROCESADO', 'Error')
        """,
        (ruta, nombre_original),
    )
    documento_id = cur.lastrowid
    conn.execute(
        """
        INSERT INTO log_operaciones (documento_id, accion, resultado, detalle)
        VALUES (?, 'ingesta', 'error', ?)
        """,
        (documento_id, f"Archivo corrupto o ilegible: {motivo}"),
    )
    conn.commit()
    return documento_id
