"""
Fase 5 (soporte) — Orquestador del pipeline.

Conecta las Fases 1-4, ya construidas y probadas por separado, y persiste
sus resultados en `paginas` y `documentos` para que la interfaz de
confirmación humana (Fase 5) tenga algo sobre lo cual mostrar y confirmar.

No decide nada nuevo: cada paso delega en el módulo ya probado
(ingest, ocr, text_extraction, classification.engine, segmentation,
duplicates). Este módulo solo orquesta y persiste.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pikepdf

from core.classification.engine import clasificar_pagina
from core.date_utils import extraer_fecha_documental
from core.duplicates import (
    detectar_duplicado_por_contenido,
    detectar_duplicado_por_hash,
    registrar_duplicado,
)
from core.ingest import validar_pdf
from core.ocr import ErrorOCR, aplicar_ocr
from core.segmentation import segmentar
from core.text_extraction import extraer_texto_por_pagina

DIR_OCR_TEMPORAL = "data/ocr_tmp"
DIR_SEGMENTOS = "data/segmentos"


def procesar_archivo(conn: sqlite3.Connection, ruta_entrada: str) -> list[int]:
    """
    Procesa un único PDF de entrada de punta a punta hasta dejarlo en
    `Pendiente_Validacion` (o `Error`/`NO_PROCESADO` según corresponda).
    Devuelve la lista de ids de `documentos` generados (uno por sub-documento
    tras la segmentación).
    """
    doc = validar_pdf(ruta_entrada, conn)
    if doc is None:
        # validar_pdf ya registró el documento como NO_PROCESADO / Error.
        return []

    ruta_ocr = f"{DIR_OCR_TEMPORAL}/{doc.hash}.pdf"
    Path(DIR_OCR_TEMPORAL).mkdir(parents=True, exist_ok=True)
    try:
        aplicar_ocr(doc.ruta_original, ruta_ocr)
    except ErrorOCR as exc:
        _registrar_error_ocr(conn, doc, str(exc))
        return []

    paginas_texto = extraer_texto_por_pagina(ruta_ocr)
    clasificaciones = [
        clasificar_pagina(conn, p.numero_pagina, p.texto) for p in paginas_texto
    ]
    grupos = segmentar(clasificaciones)

    ids_documentos: list[int] = []
    for indice, grupo in enumerate(grupos, start=1):
        texto_grupo = "\n".join(
            paginas_texto[n - 1].texto for n in grupo.paginas
        )
        estado = "NO_PROCESADO" if not grupo.resuelto else "OK"
        estado_proceso = "Pendiente_Validacion"
        fecha_documental = extraer_fecha_documental(texto_grupo)

        # Extraer físicamente solo las páginas de este grupo a un PDF nuevo.
        # Sin este paso, cada grupo terminaría apuntando al archivo de
        # entrada completo (todas las páginas), en vez de a su propio
        # subconjunto — el bug real detectado con un documento de prueba: dos
        # documentos con nombres correctos (HC y OS) pero ambos con las 5
        # páginas completas, porque nunca se recortaban.
        ruta_segmento = _extraer_paginas(ruta_ocr, grupo.paginas, doc.hash, indice)

        cur = conn.execute(
            """
            INSERT INTO documentos (
                hash, ruta_original, ruta_segmento, nombre_original, sigla_id,
                especialidad_asunto, entidad_id, miembro_id,
                texto_extraido, fecha_documental, estado, estado_proceso
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                doc.hash, doc.ruta_original, ruta_segmento, doc.nombre_original,
                grupo.sigla_id, grupo.especialidad_asunto, grupo.entidad_id,
                grupo.miembro_id, texto_grupo, fecha_documental, estado, estado_proceso,
            ),
        )
        documento_id = cur.lastrowid
        ids_documentos.append(documento_id)

        for numero_pagina in grupo.paginas:
            conn.execute(
                """
                INSERT INTO paginas (
                    documento_id, numero_pagina, sigla_id,
                    especialidad_asunto, entidad_id, miembro_id, resuelta
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    documento_id, numero_pagina, grupo.sigla_id,
                    grupo.especialidad_asunto, grupo.entidad_id,
                    grupo.miembro_id, int(grupo.resuelto),
                ),
            )

        if grupo.resuelto:
            _aplicar_deteccion_duplicados(conn, documento_id, doc.hash, doc.ruta_original, texto_grupo, grupo.sigla_id)

        conn.execute(
            "INSERT INTO log_operaciones (documento_id, accion, resultado, detalle) VALUES (?, 'clasificado', ?, ?)",
            (documento_id, "OK" if grupo.resuelto else "sin_resolver", f"páginas {grupo.paginas}"),
        )

    conn.commit()
    return ids_documentos


def _extraer_paginas(ruta_pdf_ocr: str, paginas: list[int], hash_archivo: str, indice_grupo: int) -> str:
    """
    Crea un PDF nuevo con únicamente las páginas indicadas (1-indexadas),
    conservando el texto OCR ya embebido. Nunca modifica el PDF de origen.
    """
    Path(DIR_SEGMENTOS).mkdir(parents=True, exist_ok=True)
    ruta_salida = f"{DIR_SEGMENTOS}/{hash_archivo}_{indice_grupo}.pdf"

    with pikepdf.open(ruta_pdf_ocr) as origen:
        nuevo = pikepdf.Pdf.new()
        for numero_pagina in paginas:
            nuevo.pages.append(origen.pages[numero_pagina - 1])
        nuevo.save(ruta_salida)

    return ruta_salida


def _aplicar_deteccion_duplicados(
    conn: sqlite3.Connection, documento_id: int, hash_archivo: str, ruta_original: str, texto: str, sigla_id: int
) -> None:
    dup_hash = detectar_duplicado_por_hash(
        conn, hash_archivo, excluir_documento_id=documento_id, excluir_ruta_original=ruta_original
    )
    if dup_hash is not None:
        registrar_duplicado(conn, documento_id, dup_hash, "hash")
        return

    dup_contenido = detectar_duplicado_por_contenido(conn, texto, sigla_id, excluir_documento_id=documento_id)
    if dup_contenido is not None:
        registrar_duplicado(conn, documento_id, dup_contenido, "contenido")


def _registrar_error_ocr(conn: sqlite3.Connection, doc, motivo: str) -> None:
    cur = conn.execute(
        """
        INSERT INTO documentos (hash, ruta_original, nombre_original, estado, estado_proceso)
        VALUES (?, ?, ?, 'NO_PROCESADO', 'Error')
        """,
        (doc.hash, doc.ruta_original, doc.nombre_original),
    )
    conn.execute(
        "INSERT INTO log_operaciones (documento_id, accion, resultado, detalle) VALUES (?, 'ocr', 'error', ?)",
        (cur.lastrowid, motivo),
    )
    conn.commit()
