"""
Fase 1 — Extracción de texto por página.

Se ejecuta SIEMPRE después de ocr.py, que ya garantizó que toda página tiene
texto (nativo u OCR, según correspondiera). Este módulo solo lee ese texto;
no decide si hace falta OCR — esa decisión ya la resolvió OCRmyPDF con
--skip-text en el paso anterior del pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass

from pypdf import PdfReader


@dataclass
class TextoPagina:
    numero_pagina: int  # 1-indexado, consistente con el resto del pipeline
    texto: str


def extraer_texto_por_pagina(ruta_pdf: str) -> list[TextoPagina]:
    lector = PdfReader(ruta_pdf)
    return [
        TextoPagina(numero_pagina=i, texto=(pagina.extract_text() or "").strip())
        for i, pagina in enumerate(lector.pages, start=1)
    ]
