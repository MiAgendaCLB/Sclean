"""
Fase 2 — Acceso a reglas de clasificación.

Encapsula la lectura de `reglas_clasificacion` en el orden ya decidido:
generales primero (entidad_id NULL), luego por institución, ordenadas por
prioridad dentro de cada grupo.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass


@dataclass
class Regla:
    id: int
    entidad_id: int | None
    patron_texto: str
    sigla_id: int
    sigla_codigo: str
    modo_especialidad_asunto: str  # 'catalogo' | 'extraido'
    especialidad_id: int | None
    patron_extraccion: str | None
    prioridad: int


def obtener_reglas_generales(conn: sqlite3.Connection) -> list[Regla]:
    return _mapear(conn.execute(
        """
        SELECT r.id, r.entidad_id, r.patron_texto, r.sigla_id, s.codigo,
               r.modo_especialidad_asunto, r.especialidad_id, r.patron_extraccion, r.prioridad
        FROM reglas_clasificacion r
        JOIN glosario_siglas s ON s.id = r.sigla_id
        WHERE r.entidad_id IS NULL AND r.activo = 1
        ORDER BY r.prioridad ASC
        """
    ).fetchall())


def obtener_reglas_institucion(conn: sqlite3.Connection, entidad_id: int) -> list[Regla]:
    return _mapear(conn.execute(
        """
        SELECT r.id, r.entidad_id, r.patron_texto, r.sigla_id, s.codigo,
               r.modo_especialidad_asunto, r.especialidad_id, r.patron_extraccion, r.prioridad
        FROM reglas_clasificacion r
        JOIN glosario_siglas s ON s.id = r.sigla_id
        WHERE r.entidad_id = ? AND r.activo = 1
        ORDER BY r.prioridad ASC
        """,
        (entidad_id,),
    ).fetchall())


def obtener_todas_las_entidades(conn: sqlite3.Connection) -> list[tuple[int, str]]:
    return conn.execute("SELECT id, nombre FROM glosario_entidades WHERE activo = 1").fetchall()


def _mapear(filas) -> list[Regla]:
    return [
        Regla(
            id=f[0], entidad_id=f[1], patron_texto=f[2], sigla_id=f[3], sigla_codigo=f[4],
            modo_especialidad_asunto=f[5], especialidad_id=f[6], patron_extraccion=f[7], prioridad=f[8],
        )
        for f in filas
    ]
