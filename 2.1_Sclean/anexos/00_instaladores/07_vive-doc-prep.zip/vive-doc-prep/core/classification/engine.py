"""
Fase 2 — Motor de clasificación.

Para cada página (con el texto ya extraído en Fase 1), determina:
  - entidad_id: por coincidencia del nombre de la institución en el texto
    contra glosario_entidades. No requiere una tabla de reglas aparte: el
    propio catálogo ya contiene el dato a buscar.
  - miembro_id: mismo criterio, contra personas.nombre_completo.
  - sigla_id y especialidad_asunto: aplicando reglas_clasificacion en el
    orden ya decidido (generales primero, luego las de la institución ya
    detectada, si existen).

"Confianza suficiente" (definición ya fijada en la arquitectura): la página
queda resuelta solo si sigla_id y miembro_id tienen valor. Si falta alguno,
la página queda sin clasificar.
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass

from core.classification.rules_repository import (
    Regla,
    obtener_reglas_generales,
    obtener_reglas_institucion,
    obtener_todas_las_entidades,
)
from core.text_utils import normalizar

_CONECTORES = {
    "y", "e", "o", "u", "de", "del", "la", "el", "los", "las",
    "en", "por", "a", "con", "para", "que", "su", "sus",
}

_FLAGS = re.IGNORECASE | re.DOTALL | re.MULTILINE


@dataclass
class ClasificacionPagina:
    numero_pagina: int
    sigla_id: int | None
    sigla_codigo: str | None
    especialidad_asunto: str | None
    entidad_id: int | None
    miembro_id: int | None
    resuelta: bool  # True si cumple la definición de "confianza suficiente"


def clasificar_pagina(conn: sqlite3.Connection, numero_pagina: int, texto: str) -> ClasificacionPagina:
    # Se normaliza el texto UNA sola vez (tildes fuera, cualquier espacio en
    # blanco/salto de línea colapsado a un solo espacio) y esa es la única
    # versión que se usa de aquí en adelante para cualquier comparación:
    # reglas de sigla, entidad, miembro y especialidad. Antes cada una tenía
    # su propia normalización parcial (o ninguna), lo que dejaba huecos como
    # patrones de sigla que exigían un espacio literal entre palabras y
    # fallaban si el documento traía un salto de línea ahí en su lugar.
    texto_norm = normalizar(texto)

    entidad_id = _detectar_entidad(conn, texto_norm)
    miembro_id = _detectar_miembro(conn, texto_norm)

    sigla_id = sigla_codigo = especialidad_asunto = None

    for regla in obtener_reglas_generales(conn):
        if re.search(normalizar(regla.patron_texto), texto_norm, _FLAGS):
            sigla_id, sigla_codigo = regla.sigla_id, regla.sigla_codigo
            especialidad_asunto = _resolver_especialidad(conn, regla, texto)
            break

    if entidad_id is not None:
        for regla in obtener_reglas_institucion(conn, entidad_id):
            if re.search(normalizar(regla.patron_texto), texto_norm, _FLAGS):
                sigla_id, sigla_codigo = regla.sigla_id, regla.sigla_codigo
                valor = _resolver_especialidad(conn, regla, texto)
                if valor:  # la regla de institución solo refina si de verdad extrajo algo
                    especialidad_asunto = valor
                break

    # Detección genérica por catálogo, igual que entidad/miembro: no depende
    # de que exista una regla propia para la institución. Una vez que una
    # especialidad se agrega al catálogo (aunque sea la primera vez a mano),
    # queda detectable automáticamente en cualquier documento futuro que la
    # mencione, sin importar la institución. Solo se aplica si ninguna regla
    # (general o de institución) ya dio un valor más específico.
    if not especialidad_asunto and sigla_codigo not in ("CI", "EM"):
        especialidad_asunto = _detectar_especialidad(conn, texto_norm)

    resuelta = sigla_id is not None and miembro_id is not None

    return ClasificacionPagina(
        numero_pagina=numero_pagina,
        sigla_id=sigla_id,
        sigla_codigo=sigla_codigo,
        especialidad_asunto=especialidad_asunto,
        entidad_id=entidad_id,
        miembro_id=miembro_id,
        resuelta=resuelta,
    )


def _detectar_especialidad(conn: sqlite3.Connection, texto_norm: str) -> str | None:
    filas = conn.execute("SELECT nombre FROM glosario_especialidades WHERE activo = 1").fetchall()
    for (nombre,) in filas:
        if normalizar(nombre) in texto_norm:
            return nombre.replace(" ", "")
    return None


def _detectar_entidad(conn: sqlite3.Connection, texto_norm: str) -> int | None:
    for entidad_id, nombre in obtener_todas_las_entidades(conn):
        if normalizar(nombre) in texto_norm:
            return entidad_id
    return None


def _detectar_miembro(conn: sqlite3.Connection, texto_norm: str) -> int | None:
    filas = conn.execute(
        "SELECT id, nombre_completo FROM personas WHERE activo = 1 AND nombre_completo IS NOT NULL"
    ).fetchall()
    for miembro_id, nombre_completo in filas:
        # Comparación por palabras, no por substring exacto: los documentos
        # colombianos suelen mostrar "APELLIDOS NOMBRE" en vez de "Nombre Apellidos".
        palabras = normalizar(nombre_completo).split()
        if palabras and all(p in texto_norm for p in palabras):
            return miembro_id
    return None


def _resolver_especialidad(conn: sqlite3.Connection, regla: Regla, texto: str) -> str | None:
    if regla.modo_especialidad_asunto == "catalogo":
        if regla.especialidad_id is None:
            return None
        fila = conn.execute(
            "SELECT nombre FROM glosario_especialidades WHERE id = ?", (regla.especialidad_id,)
        ).fetchone()
        return fila[0].replace(" ", "") if fila else None

    if not regla.patron_extraccion:
        return None
    m = re.search(regla.patron_extraccion, texto, _FLAGS)
    if not m:
        return None

    if regla.sigla_codigo == "CI" and len(m.groups()) >= 2:
        inicio = m.group(1).replace("-", "")
        fin = m.group(2).replace("-", "")
        return f"{inicio}_a_{fin}"

    if regla.sigla_codigo == "EM":
        return _normalizar_asunto(m.group(1) if m.groups() else m.group(0))

    return (m.group(1) if m.groups() else m.group(0)).strip().replace(" ", "")


def _normalizar_asunto(texto: str) -> str:
    palabras = re.findall(r"[A-Za-zÁÉÍÓÚÑÜáéíóúñü]+", texto)
    return "".join(p.capitalize() for p in palabras if p.lower() not in _CONECTORES)
