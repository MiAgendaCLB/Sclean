"""
Fase 4 — Detección de duplicados.

Dos niveles, no uno (ya definido en la especificación funcional):
  - Hash: mismo archivo exacto, aunque tenga distinto nombre o carpeta.
  - Contenido: mismo documento exportado dos veces con bytes distintos
    (ej. dos escaneos del mismo papel), detectado por similitud de texto.

No decide cuál copia es la "oficial" (selección automática queda diferida
en el backlog, ya acordado). Solo registra la relación en `duplicados`
para que el usuario decida.
"""

from __future__ import annotations

import sqlite3
from difflib import SequenceMatcher

UMBRAL_SIMILITUD_CONTENIDO = 0.92  # por encima de esto, se considera duplicado de contenido


def detectar_duplicado_por_hash(
    conn: sqlite3.Connection,
    hash_actual: str,
    excluir_documento_id: int | None = None,
    excluir_ruta_original: str | None = None,
) -> int | None:
    """
    Devuelve el id del primer documento existente con el mismo hash, o None.

    IMPORTANTE: excluye documentos que provienen del mismo archivo de origen
    (`ruta_original`). Un mismo PDF de entrada puede segmentarse en varios
    sub-documentos que comparten el hash del archivo original sin ser
    duplicados entre sí; comparar el hash sin excluir esto produce falsos
    positivos sistemáticos entre HC/OS/FM de un mismo evento.
    """
    query = "SELECT id FROM documentos WHERE hash = ?"
    params: list = [hash_actual]
    if excluir_documento_id is not None:
        query += " AND id != ?"
        params.append(excluir_documento_id)
    if excluir_ruta_original is not None:
        query += " AND ruta_original != ?"
        params.append(excluir_ruta_original)
    fila = conn.execute(query, params).fetchone()
    return fila[0] if fila else None


def detectar_duplicado_por_contenido(
    conn: sqlite3.Connection,
    texto_actual: str,
    sigla_id: int,
    excluir_documento_id: int | None = None,
) -> int | None:
    """
    Compara el texto contra otros documentos ya registrados de la misma sigla
    (comparar solo dentro del mismo tipo documental evita falsos positivos
    entre, por ejemplo, dos HC de fechas distintas que comparten mucho texto
    de plantilla). Devuelve el id del primer documento con similitud por
    encima del umbral, o None.
    """
    query = """
        SELECT id, texto_extraido FROM documentos
        WHERE sigla_id = ? AND estado != 'NO_PROCESADO' AND texto_extraido IS NOT NULL
    """
    params: list = [sigla_id]
    if excluir_documento_id is not None:
        query += " AND id != ?"
        params.append(excluir_documento_id)

    for documento_id, texto_guardado in conn.execute(query, params).fetchall():
        similitud = SequenceMatcher(None, texto_actual, texto_guardado).ratio()
        if similitud >= UMBRAL_SIMILITUD_CONTENIDO:
            return documento_id
    return None


def registrar_duplicado(
    conn: sqlite3.Connection, documento_id: int, documento_oficial_id: int, tipo_deteccion: str
) -> None:
    conn.execute(
        """
        INSERT INTO duplicados (documento_id, documento_oficial_id, tipo_deteccion)
        VALUES (?, ?, ?)
        """,
        (documento_id, documento_oficial_id, tipo_deteccion),
    )
    conn.execute(
        "UPDATE documentos SET estado = 'DUPLICADO' WHERE id = ?",
        (documento_id,),
    )
    conn.commit()
