"""
Fase 6 — Nomenclatura.

Construye el nombre oficial: AAAAMMDD_SIGLA_EspecialidadOAsunto_Entidad_Miembro.pdf

Solo opera sobre documentos ya en estado_proceso = 'Clasificado' (es decir,
que ya pasaron por la confirmación humana de la Fase 5). No genera nombres
para documentos sin confirmar: eso violaría la regla ya fijada de que la
confirmación humana es obligatoria antes de la nomenclatura.

Reglas de construcción, ya cerradas en la especificación funcional:
- La sigla es siempre obligatoria.
- "Especialidad o asunto" no lleva espacios (ya viene normalizado desde el
  motor de clasificación o la corrección manual del usuario).
- La entidad es la institución prestadora, no la aseguradora.
- El miembro son las iniciales de la persona (catálogo `personas`).
- Nunca se agregan consecutivos ni datos que no estén en el documento.
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass


class DatosIncompletos(Exception):
    """El documento no tiene los campos mínimos para generar nombre (sigla + miembro)."""


@dataclass
class NombrePropuesto:
    documento_id: int
    nombre: str


def _sin_tildes(texto: str) -> str:
    """Quita tildes y diéresis, conservando la letra base (á -> a, ñ se conserva)."""
    reemplazos = str.maketrans("áéíóúÁÉÍÓÚüÜ", "aeiouAEIOUuU")
    return texto.translate(reemplazos)


def _limpiar_segmento(texto: str) -> str:
    """
    Quita cualquier carácter que no sea válido en un nombre de archivo, y
    quita tildes/diacríticos (para evitar problemas de compatibilidad entre
    sistemas de archivos) — se aplica siempre, sin importar de dónde venga
    el valor (catálogo, regla de institución, detección automática, o
    corrección manual del usuario).

    Si el segmento contiene espacios (viene de catálogo, ej. "Oportunidad de
    Vida", "Cirugía Oncológica"), se capitaliza por palabra y se concatena.

    Si NO contiene espacios, ya viene preprocesado desde el motor de
    clasificación (ej. el asunto de EM o el rango de fechas de CI, que ya
    traen su propia capitalización interna construida palabra por palabra) y
    no se reprocesa por palabras — reprocesarlo lo rompería, porque no hay
    separador entre palabras para identificarlas de nuevo. Solo se le quitan
    tildes y caracteres inválidos.
    """
    texto = texto.strip()
    texto = re.sub(r"[\\/:*?\"<>|]", "", texto)
    if " " not in texto:
        return _sin_tildes(texto)
    palabras = re.findall(r"[A-Za-zÁÉÍÓÚÑÜáéíóúñü0-9]+", texto)
    return _sin_tildes("".join(p.capitalize() for p in palabras))


def construir_nombre(conn: sqlite3.Connection, documento_id: int) -> NombrePropuesto:
    fila = conn.execute(
        """
        SELECT d.fecha_documental, s.codigo AS sigla, d.especialidad_asunto,
               e.nombre AS entidad, p.iniciales AS miembro, d.estado_proceso
        FROM documentos d
        LEFT JOIN glosario_siglas s ON s.id = d.sigla_id
        LEFT JOIN glosario_entidades e ON e.id = d.entidad_id
        LEFT JOIN personas p ON p.id = d.miembro_id
        WHERE d.id = ?
        """,
        (documento_id,),
    ).fetchone()

    if fila is None:
        raise DatosIncompletos(f"No existe el documento {documento_id}")

    fecha, sigla, especialidad_asunto, entidad, miembro, estado_proceso = fila

    if estado_proceso != "Clasificado":
        raise DatosIncompletos(
            f"El documento {documento_id} no ha sido confirmado por el usuario "
            f"(estado_proceso={estado_proceso}); la nomenclatura solo se genera "
            f"después de la confirmación humana."
        )

    if not sigla or not miembro:
        raise DatosIncompletos(
            f"El documento {documento_id} no tiene sigla y/o miembro definidos; "
            f"son los dos campos obligatorios de la fórmula de nomenclatura."
        )

    segmentos = [
        fecha or "SINFECHA",
        sigla,
    ]
    if especialidad_asunto:
        segmentos.append(_limpiar_segmento(especialidad_asunto))
    if entidad:
        segmentos.append(_limpiar_segmento(entidad))
    segmentos.append(miembro)

    nombre = "_".join(segmentos) + ".pdf"
    return NombrePropuesto(documento_id=documento_id, nombre=nombre)


def guardar_nombre_propuesto(conn: sqlite3.Connection, resultado: NombrePropuesto) -> None:
    conn.execute(
        "UPDATE documentos SET nombre_propuesto = ? WHERE id = ?",
        (resultado.nombre, resultado.documento_id),
    )
    conn.execute(
        "INSERT INTO log_operaciones (documento_id, accion, resultado, detalle) VALUES (?, 'nomenclatura', 'OK', ?)",
        (resultado.documento_id, resultado.nombre),
    )
    conn.commit()
