"""
Extracción de fecha documental desde el texto de un documento.

Prioridad ya definida en la especificación funcional: la fecha del contenido
siempre gana sobre la fecha de escaneo/impresión. Este módulo busca patrones
de fecha ya vistos en los documentos reales usados en las pruebas de
análisis. No es exhaustivo para toda institución posible; instituciones
nuevas que usen otro formato deben agregar su propio patrón aquí, del mismo
modo que se agregan reglas de clasificación nuevas.
"""

from __future__ import annotations

import re

_MESES = {
    "ene": "01", "feb": "02", "mar": "03", "abr": "04", "may": "05", "jun": "06",
    "jul": "07", "ago": "08", "sep": "09", "oct": "10", "nov": "11", "dic": "12",
}

_MESES_COMPLETOS = {
    "enero": "01", "febrero": "02", "marzo": "03", "abril": "04", "mayo": "05", "junio": "06",
    "julio": "07", "agosto": "08", "septiembre": "09", "setiembre": "09",
    "octubre": "10", "noviembre": "11", "diciembre": "12",
}

_FECHA_AAAAMMDD = r"(\d{4})[/-](\d{2})[/-](\d{2})"
_FECHA_DDMMAAAA = r"(\d{2})/(\d{2})/(\d{4})"
_FECHA_DIA_MES_ABREV = r"(\d{1,2})\s+(ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)\.?\s+(\d{4})"
_FECHA_DIA_MES_COMPLETO = (
    r"(\d{1,2})\s+de\s+"
    r"(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)"
    r"\s+de\s+(\d{4})"
)

_NORMALIZAR_AAAAMMDD = lambda m: f"{m[0]}{m[1]}{m[2]}"
_NORMALIZAR_DDMMAAAA = lambda m: f"{m[2]}{m[1]}{m[0]}"
_NORMALIZAR_DIA_MES_ABREV = lambda m: f"{m[2]}{_MESES[m[1].lower()]}{m[0].zfill(2)}"
_NORMALIZAR_DIA_MES_COMPLETO = lambda m: f"{m[2]}{_MESES_COMPLETOS[m[1].lower()]}{m[0].zfill(2)}"

# Prioridad 1: fecha anclada a una etiqueta que identifica la fecha DEL
# DOCUMENTO (no la fecha de nacimiento del paciente ni otro dato irrelevante).
# Se prueban en orden; la primera etiqueta que aparezca en el texto gana.
_PATRONES_CON_ETIQUETA = [
    (re.compile(rf"Fecha de la nota:?\s*{_FECHA_DDMMAAAA}", re.IGNORECASE), _NORMALIZAR_DDMMAAAA),
    (re.compile(rf"Fecha de la nota:?\s*{_FECHA_AAAAMMDD}", re.IGNORECASE), _NORMALIZAR_AAAAMMDD),
    (re.compile(rf"Fecha y Hora de Solicitud:?\s*{_FECHA_DDMMAAAA}", re.IGNORECASE), _NORMALIZAR_DDMMAAAA),
    (re.compile(rf"Fecha Atencion:?\s*{_FECHA_AAAAMMDD}", re.IGNORECASE), _NORMALIZAR_AAAAMMDD),
    (re.compile(rf"Fecha Ingreso:?\s*{_FECHA_AAAAMMDD}", re.IGNORECASE), _NORMALIZAR_AAAAMMDD),
    (re.compile(rf"^Fecha:?\s*{_FECHA_DIA_MES_ABREV}", re.IGNORECASE | re.MULTILINE), _NORMALIZAR_DIA_MES_ABREV),
    (re.compile(rf"^Fecha:?\s*{_FECHA_DDMMAAAA}", re.IGNORECASE | re.MULTILINE), _NORMALIZAR_DDMMAAAA),
    (re.compile(rf"Fecha de Impresi[oó]n:?\s*{_FECHA_AAAAMMDD}", re.IGNORECASE), _NORMALIZAR_AAAAMMDD),
]

# Prioridad 2: sin etiqueta, cualquier fecha suelta en el texto — pero nunca
# la que sigue a "Fecha de nacimiento", que identifica al paciente, no al
# documento. Tolerante a texto intermedio entre la etiqueta y la fecha (ej.
# "Fecha y hora de nacimiento (dd/mm/aaaa hh:mm): 11/09/1984") — la versión
# anterior exigía que la fecha viniera inmediatamente después de la etiqueta
# y fallaba en variantes con esa aclaración entre paréntesis, dejando pasar
# la fecha de nacimiento como si fuera la fecha del documento.
_PATRON_NACIMIENTO = re.compile(
    r"Fecha(\s+y\s+hora)?\s+de\s+nacimiento[^:\n]*:?\s*\d{1,4}[/-]\d{1,2}[/-]\d{1,4}(\s+\d{1,2}:\d{2})?",
    re.IGNORECASE,
)

_PATRONES_SIN_ETIQUETA = [
    (re.compile(_FECHA_AAAAMMDD), _NORMALIZAR_AAAAMMDD),
    (re.compile(_FECHA_DIA_MES_COMPLETO, re.IGNORECASE), _NORMALIZAR_DIA_MES_COMPLETO),
    (re.compile(_FECHA_DDMMAAAA), _NORMALIZAR_DDMMAAAA),
    (re.compile(_FECHA_DIA_MES_ABREV, re.IGNORECASE), _NORMALIZAR_DIA_MES_ABREV),
]


def extraer_fecha_documental(texto: str) -> str | None:
    """
    Devuelve la primera fecha encontrada, normalizada a AAAAMMDD, o None.
    Prioriza fechas ancladas a una etiqueta que identifica la fecha del
    documento; si ninguna etiqueta conocida aparece, cae a buscar cualquier
    fecha suelta, excluyendo explícitamente la fecha de nacimiento del
    paciente (identifica a la persona, no al documento).
    """
    for patron, normalizar in _PATRONES_CON_ETIQUETA:
        m = patron.search(texto)
        if m:
            return normalizar(m.groups())

    texto_sin_nacimiento = _PATRON_NACIMIENTO.sub("", texto)
    for patron, normalizar in _PATRONES_SIN_ETIQUETA:
        m = patron.search(texto_sin_nacimiento)
        if m:
            return normalizar(m.groups())
    return None
