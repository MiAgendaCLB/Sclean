"""
Normalización de texto para comparaciones (no para el nombre final del
archivo, eso lo maneja naming.py aparte).

Un solo punto centralizado, usado por todo el motor de clasificación
(entidad, miembro, especialidad) y por la extracción de fechas. Corrige dos
problemas reales encontrados por separado y que resultaron ser la misma
clase de error:

1. Tildes: el texto real de un documento puede venir sin tildes (ej.
   "CLINICA IMBANACO" en mayúsculas de formulario) mientras el catálogo las
   tiene ("Clínica Imbanaco"). Una comparación exacta falla aunque el
   contenido sea el mismo.
2. Espacios en blanco: el texto extraído de un PDF puede partir palabras que
   van juntas en el catálogo en líneas distintas (ej. "Clínica\nImbanaco" en
   vez de "Clínica Imbanaco"), por cómo quedó diagramado el documento
   original. Una comparación que exige un espacio literal falla aunque la
   palabra esté perfectamente legible.

Cualquier comparación de texto nueva en el proyecto debe pasar sus dos
lados por `normalizar()` antes de comparar, no reimplementar esto aparte.
"""

from __future__ import annotations

import re

_TABLA_TILDES = str.maketrans("áéíóúÁÉÍÓÚüÜ", "aeiouAEIOUuU")


def normalizar(texto: str) -> str:
    """Minúsculas, sin tildes/diéresis, y cualquier espacio en blanco (incluyendo
    saltos de línea y tabs) colapsado a un solo espacio."""
    texto = texto.lower().translate(_TABLA_TILDES)
    return re.sub(r"\s+", " ", texto).strip()
