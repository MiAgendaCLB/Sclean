# Contexto del proyecto Sclean — para retomar en un chat nuevo

Pega esto al inicio de la conversación nueva, junto con el zip `vive-doc-prep.zip`.

## Qué es este proyecto

Sclean es una app local y portable (Python + Flask + SQLite, empaquetada con PyInstaller) que recibe PDFs escaneados médicos/administrativos, los clasifica automáticamente, les asigna un nombre oficial y los deja listos para importar a otro sistema (BDVive). Corre en Windows con doble clic, sin instalar nada aparte; accesible desde PC y desde el teléfono en la misma red Wi-Fi.

## Decisiones ya cerradas (no volver a discutir salvo que algo lo justifique)

- **Nomenclatura oficial**: `AAAAMMDD_SIGLA_EspecialidadOAsunto_Entidad_Miembro.pdf`. La sigla es siempre obligatoria; los demás campos dependen del tipo de documento.
- **Catálogo de siglas**: HC (Historia Clínica), OS (Orden de Servicio — consolida todas las órdenes de un mismo evento en un solo documento), FM (Fórmula Médica, siempre aparte), IS (Insumos), CI (Incapacidad Médica, usa rango de fechas en vez de especialidad), EM (Correspondencia/comunicaciones).
- **Entidad** = institución prestadora (dónde se generó), no la aseguradora/EPS.
- **Miembro** = iniciales de la persona del catálogo Personas (ej. CLB, YHM, OLF).
- **Clasificación**: motor de reglas por patrón de texto (SQL + reglas por institución), NO usa IA en el flujo principal — es determinista y funciona sin internet.
- **Estado dual del documento**: `estado` (resultado: OK/RENOMBRAR/DUPLICADO/NO_PROCESADO/LISTO_PARA_IMPORTAR) y `estado_proceso` (ciclo de vida: Recibido/En_Proceso/Pendiente_Validacion/Clasificado/Exportado/Error) son dos columnas independientes, no una sola.
- **Confirmación humana obligatoria** antes de generar el nombre final — nunca se renombra nada sin que el usuario confirme o corrija.
- **Un clic confirma y termina todo**: al confirmar, se encadenan automáticamente nomenclatura + movimiento a la carpeta de salida (menos pasos manuales, importante por la situación del usuario tras un ACV).
- **Accesible desde PC y teléfono**: el servidor escucha en `0.0.0.0`, no solo en localhost. Esto expone la app a la red Wi-Fi local — aceptado conscientemente, solo usar en redes de confianza.

## Estado técnico actual

Las 10 fases del MVP están implementadas y probadas con 4 documentos reales (Clínica Imbanaco, Oportunidad de Vida, Neurólogos de Occidente, un correo). El backend, la interfaz web y el empaquetado con PyInstaller ya funcionan, verificados en un entorno Linux con aislamiento total (sin PATH del sistema).

**Bugs reales ya encontrados y corregidos en el código** (por si reaparecen variantes al probar en Windows):
- PyInstaller no compila para un sistema operativo distinto al que lo ejecuta (hay que correr el build en Windows para obtener el `.exe` de Windows).
- `LD_LIBRARY_PATH` que fija PyInstaller puede interferir con binarios externos.
- `ocrmypdf` necesita `--collect-all ocrmypdf` en el build para que registre su motor OCR (usa entry_points).
- Ghostscript se llama `gswin64c`/`gswin32c` en Windows, no `gs` (nombre de Linux/Mac) — ya corregido buscando varios nombres.
- Tesseract necesita también sus carpetas `configs/`/`tessconfigs/`, no solo los `.traineddata`.
- Las rutas de subida/salida y el registro de errores de OCR deben resolverse relativas al ejecutable real (`sys.executable`), no al archivo de código dentro de la carpeta interna de PyInstaller (`_internal`) — ya corregido.

**Pendiente de verificar**: el `.exe` real de Windows aún no se ha probado de punta a punta en una máquina Windows real (solo el equivalente en Linux). Es el paso inmediato siguiente: correr `python build_scripts/empaquetar.py` en Windows y probar subir un PDF real.

## Cómo pedir ayuda en el chat nuevo

Ejemplo de primer mensaje:

> "Este es el proyecto Sclean (adjunto zip). Ya tengo Python, Tesseract, Ghostscript y qpdf instalados en Windows. Ayúdame a correr `build_scripts/empaquetar.py` y a resolver los errores que salgan al probar la app."
