// Interfaz de Sclean: subir PDFs, revisar clasificación propuesta, confirmar
// o corregir con un clic. Pensado para pantallas de celular y de PC por
// igual (mismo HTML, CSS responsivo).

const inputArchivos = document.getElementById("inputArchivos");
const nombresElegidos = document.getElementById("nombresElegidos");
const botonProcesar = document.getElementById("botonProcesar");
const cargando = document.getElementById("cargando");
const listaDocumentos = document.getElementById("listaDocumentos");
const zonaSubida = document.getElementById("zonaSubida");

let catalogos = { siglas: [], entidades: [], especialidades: [], personas: [] };

// Lista acumulativa de archivos elegidos. El <input type=file> por sí solo
// REEMPLAZA la selección anterior cada vez que se usa (comportamiento nativo
// del navegador) — por eso elegir 1 archivo y luego elegir 3 de otra carpeta
// dejaba solo los 3 últimos. Se mantiene esta lista aparte y se acumula
// manualmente, tanto al elegir con el botón como al soltar archivos.
let archivosAcumulados = [];

function agregarArchivos(listaArchivos) {
  for (const archivo of listaArchivos) {
    if (archivo.type === "application/pdf" || archivo.name.toLowerCase().endsWith(".pdf")) {
      archivosAcumulados.push(archivo);
    }
  }
  actualizarVistaSeleccion();
}

function actualizarVistaSeleccion() {
  nombresElegidos.textContent = archivosAcumulados.map(a => a.name).join(", ");
  botonProcesar.classList.toggle("oculto", archivosAcumulados.length === 0);
}

inputArchivos.addEventListener("change", () => {
  agregarArchivos(Array.from(inputArchivos.files));
  inputArchivos.value = ""; // permite volver a elegir de otra carpeta sin perder lo ya acumulado
});

// Arrastrar y soltar PDFs directamente sobre la zona de subida.
["dragenter", "dragover"].forEach(evento => {
  zonaSubida.addEventListener(evento, (e) => {
    e.preventDefault();
    zonaSubida.classList.add("arrastrando");
  });
});
["dragleave", "drop"].forEach(evento => {
  zonaSubida.addEventListener(evento, (e) => {
    e.preventDefault();
    zonaSubida.classList.remove("arrastrando");
  });
});
zonaSubida.addEventListener("drop", (e) => {
  const archivos = e.dataTransfer && e.dataTransfer.files ? Array.from(e.dataTransfer.files) : [];
  agregarArchivos(archivos);
});

botonProcesar.addEventListener("click", async () => {
  if (!archivosAcumulados.length) return;

  const formData = new FormData();
  for (const archivo of archivosAcumulados) formData.append("archivos", archivo);

  cargando.classList.remove("oculto");
  botonProcesar.disabled = true;
  try {
    await fetch("/subir", { method: "POST", body: formData });
  } catch (e) {
    alert("No se pudo conectar con el servidor. Intenta de nuevo.");
  } finally {
    cargando.classList.add("oculto");
    botonProcesar.disabled = false;
    archivosAcumulados = [];
    actualizarVistaSeleccion();
    await cargarDocumentos();
  }
});

async function cargarCatalogos() {
  const resp = await fetch("/catalogos");
  catalogos = await resp.json();
}

async function cargarDocumentos() {
  const resp = await fetch("/documentos");
  const documentos = await resp.json();
  listaDocumentos.innerHTML = "";

  if (documentos.length === 0) {
    listaDocumentos.innerHTML = '<div class="tarjeta"><p>No hay documentos pendientes de revisión ahora mismo.</p></div>';
    return;
  }

  const contenedor = document.createElement("div");
  contenedor.className = "tarjeta";
  contenedor.innerHTML = `<div class="estado-global">${documentos.length} documento(s) esperando confirmación</div>`;

  documentos.forEach(doc => contenedor.appendChild(renderizarDocumento(doc)));
  listaDocumentos.appendChild(contenedor);
}

function renderizarDocumento(doc) {
  const fila = document.createElement("div");
  fila.className = "fila-doc";

  const resuelto = doc.estado === "OK";
  const etiqueta = resuelto
    ? `<span class="etiqueta ok">Detectado: ${doc.sigla || "?"}</span>`
    : `<span class="etiqueta revisar">Necesita revisión manual</span>`;

  fila.innerHTML = `
    <div class="nombre">${doc.nombre_original}</div>
    <div>${etiqueta}</div>
    <div class="fila-selects">
      <div>
        <label>Tipo de documento (sigla)</label>
        ${renderizarSelect("sigla", doc, catalogos.siglas, "codigo")}
      </div>
      <div>
        <label>Miembro de la familia</label>
        ${renderizarSelect("miembro", doc, catalogos.personas, "iniciales")}
      </div>
    </div>
    <label>Entidad</label>
    ${renderizarSelect("entidad", doc, catalogos.entidades, "nombre")}
    <label>Especialidad o asunto</label>
    ${renderizarSelectEspecialidad(doc)}
    <div style="margin-top:14px; display:flex; gap:10px; flex-wrap: wrap;">
      <button class="boton verde" data-accion="confirmar">Confirmar</button>
      <button class="boton secundario" data-accion="paginas">Ver páginas</button>
    </div>
    <div class="resultado"></div>
  `;

  fila.querySelector('[data-accion="confirmar"]').addEventListener("click", () => confirmarDocumento(doc.id, fila));
  fila.querySelector('[data-accion="paginas"]').addEventListener("click", () => mostrarPaginas(doc.id, fila));

  return fila;
}

function renderizarSelect(campo, doc, opciones, campoTexto) {
  const valorActual = doc[campo];
  let html = `<select data-campo="${campo}">`;
  html += `<option value="">${valorActual || "(sin definir)"}</option>`;
  opciones.forEach(op => {
    html += `<option value="${op.id}">${op[campoTexto]}</option>`;
  });
  html += `<option value="__otro__">Otro (crear nuevo)…</option>`;
  html += `</select>`;
  return html;
}

function renderizarSelectEspecialidad(doc) {
  // especialidad_asunto es texto libre en la base de datos (no un id de
  // catálogo), porque para CI/EM su valor se calcula del propio contenido
  // (rango de fechas, asunto del correo) y no siempre viene de un catálogo.
  // Por eso el select trabaja con el nombre como valor, no con un id.
  const valorActual = doc.especialidad_asunto;
  let html = `<select data-campo="especialidad_asunto">`;
  html += `<option value="">${valorActual || "(sin definir, dejar como está)"}</option>`;
  catalogos.especialidades.forEach(op => {
    html += `<option value="${op.nombre}">${op.nombre}</option>`;
  });
  html += `<option value="__otro__">Otro (escribir)…</option>`;
  html += `</select>`;
  return html;
}

async function confirmarDocumento(id, fila) {
  const seleccionSigla = fila.querySelector('[data-campo="sigla"]').value;
  const seleccionMiembro = fila.querySelector('[data-campo="miembro"]').value;
  const seleccionEntidad = fila.querySelector('[data-campo="entidad"]').value;
  const seleccionEspecialidad = fila.querySelector('[data-campo="especialidad_asunto"]').value;

  const cuerpo = {};
  let seCreoAlgoNuevo = false;

  if (seleccionSigla === "__otro__") {
    const codigo = prompt("Código de la nueva sigla (ej. RE):");
    const nombre = codigo && prompt("Nombre de la nueva sigla:");
    if (codigo && nombre) {
      const r = await fetch("/catalogos/siglas", {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({codigo, nombre}),
      });
      const nueva = await r.json();
      cuerpo.sigla_id = nueva.id;
      seCreoAlgoNuevo = true;
    }
  } else if (seleccionSigla) {
    cuerpo.sigla_id = parseInt(seleccionSigla, 10);
  }

  if (seleccionMiembro === "__otro__") {
    const iniciales = prompt("Iniciales del nuevo miembro (ej. ABC):");
    const nombreCompleto = iniciales && prompt("Nombre completo:");
    if (iniciales) {
      const r = await fetch("/catalogos/personas", {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({iniciales, nombre_completo: nombreCompleto || ""}),
      });
      const nueva = await r.json();
      cuerpo.miembro_id = nueva.id;
      seCreoAlgoNuevo = true;
    }
  } else if (seleccionMiembro) {
    cuerpo.miembro_id = parseInt(seleccionMiembro, 10);
  }

  if (seleccionEntidad === "__otro__") {
    const nombre = prompt("Nombre de la nueva entidad:");
    const tipo = nombre && prompt("Tipo (prestador / aseguradora):", "prestador");
    if (nombre && tipo) {
      const r = await fetch("/catalogos/entidades", {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({nombre, tipo}),
      });
      const nueva = await r.json();
      cuerpo.entidad_id = nueva.id;
      seCreoAlgoNuevo = true;
    }
  } else if (seleccionEntidad) {
    cuerpo.entidad_id = parseInt(seleccionEntidad, 10);
  }

  if (seleccionEspecialidad === "__otro__") {
    const nueva = prompt("Especialidad o asunto (sin escribir espacios especiales, se ajusta automáticamente):");
    if (nueva) {
      cuerpo.especialidad_asunto = nueva;
      // Se guarda también en el catálogo para poder reutilizarla luego sin volver a escribirla.
      await fetch("/catalogos/especialidades", {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({nombre: nueva}),
      });
      seCreoAlgoNuevo = true;
    }
  } else if (seleccionEspecialidad) {
    cuerpo.especialidad_asunto = seleccionEspecialidad;
  }

  const resp = await fetch(`/documentos/${id}/confirmar`, {
    method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify(cuerpo),
  });
  const resultado = await resp.json();

  // Si se creó una sigla/entidad/persona nueva vía "Otro", hay que refrescar
  // los catálogos y volver a dibujar TODA la lista de pendientes — de lo
  // contrario, otros documentos ya renderizados (ej. la OS del mismo evento)
  // se quedan con el desplegable viejo, sin la entrada recién creada, y el
  // usuario termina creando el mismo valor por duplicado sin darse cuenta.
  if (seCreoAlgoNuevo) {
    await cargarCatalogos();
    await cargarDocumentos();
    return;
  }

  const zonaResultado = fila.querySelector(".resultado");
  if (resultado.nombre_final) {
    zonaResultado.innerHTML = `<div class="exito">Listo: ${resultado.nombre_final}</div>`;
    setTimeout(() => { fila.remove(); }, 1500);
  } else if (resultado.advertencia) {
    zonaResultado.innerHTML = `<div class="aviso">${resultado.advertencia}</div>`;
  } else {
    zonaResultado.innerHTML = `<div class="aviso">Guardado. Sigue en revisión (faltan datos).</div>`;
  }
}

async function mostrarPaginas(id, fila) {
  const resp = await fetch(`/documentos/${id}/paginas`);
  const paginas = await resp.json();
  const zonaResultado = fila.querySelector(".resultado");
  zonaResultado.innerHTML = "<div style='margin-top:8px; font-size:0.9rem;'>" +
    paginas.map(p => `Página ${p.numero_pagina}: ${p.resuelta ? "resuelta" : "sin resolver"}`).join("<br>") +
    "</div>";
}

(async function iniciar() {
  await cargarCatalogos();
  await cargarDocumentos();
})();
