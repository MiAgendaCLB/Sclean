"""
Fase 5 — Interfaz de confirmación humana (backend).

Expone lo mínimo para que el usuario vea el resultado de un lote y
confirme o corrija cada documento con un clic, antes de que continúe
hacia nomenclatura (Fase 6). No permite avanzar sin este paso: no existe
ningún endpoint que salte directo a "listo para importar" sin haber
pasado por /confirmar.
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.utils import secure_filename

from core.pipeline import procesar_archivo
from core.naming import DatosIncompletos, construir_nombre, guardar_nombre_propuesto
from core.file_ops import OperacionFallida, mover_a_listos_para_importar

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get("VIVE_DB_PATH", str(BASE_DIR / "data" / "vive_docs.db")))
CARPETA_SUBIDOS = Path(os.environ.get("VIVE_UPLOADS_PATH", str(BASE_DIR / "data" / "subidos")))
CARPETA_SALIDA = Path(os.environ.get("VIVE_SALIDA_PATH", str(BASE_DIR / "Listos_para_importar")))

app = Flask(__name__, static_folder="static", template_folder="static")


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/subir")
def subir_archivos():
    """
    Recibe uno o varios PDFs desde el navegador (input type=file), los
    guarda en data/subidos y dispara el pipeline completo sobre cada uno.
    """
    archivos = request.files.getlist("archivos")
    if not archivos:
        return jsonify({"error": "No se recibió ningún archivo"}), 400

    CARPETA_SUBIDOS.mkdir(parents=True, exist_ok=True)
    conn = _conn()
    try:
        resultado = {}
        for archivo in archivos:
            nombre_seguro = secure_filename(archivo.filename)
            ruta_guardado = CARPETA_SUBIDOS / nombre_seguro
            archivo.save(ruta_guardado)
            resultado[nombre_seguro] = procesar_archivo(conn, str(ruta_guardado))
        return jsonify({"procesados": resultado})
    finally:
        conn.close()


@app.get("/catalogos")
def listar_catalogos():
    """Catálogos para llenar los selects de corrección manual en la interfaz."""
    conn = _conn()
    try:
        return jsonify({
            "siglas": [dict(f) for f in conn.execute("SELECT id, codigo, nombre FROM glosario_siglas WHERE activo=1").fetchall()],
            "entidades": [dict(f) for f in conn.execute("SELECT id, nombre, tipo FROM glosario_entidades WHERE activo=1").fetchall()],
            "especialidades": [dict(f) for f in conn.execute("SELECT id, nombre FROM glosario_especialidades WHERE activo=1").fetchall()],
            "personas": [dict(f) for f in conn.execute("SELECT id, iniciales, nombre_completo FROM personas WHERE activo=1").fetchall()],
        })
    finally:
        conn.close()


@app.post("/catalogos/<tabla>")
def crear_entrada_catalogo(tabla: str):
    """
    Patrón "Otro -> crear nuevo": agrega una entrada nueva al catálogo
    correspondiente, sin tocar código. Tablas permitidas: siglas, entidades,
    especialidades, personas.
    """
    tablas_validas = {
        "siglas": ("glosario_siglas", ["codigo", "nombre"]),
        "entidades": ("glosario_entidades", ["nombre", "tipo"]),
        "especialidades": ("glosario_especialidades", ["nombre"]),
        "personas": ("personas", ["iniciales", "nombre_completo"]),
    }
    if tabla not in tablas_validas:
        return jsonify({"error": f"Catálogo desconocido: {tabla}"}), 400

    nombre_tabla, campos = tablas_validas[tabla]
    datos = request.get_json(force=True) or {}
    valores = [datos.get(c) for c in campos]
    if any(v is None for v in valores):
        return jsonify({"error": f"Faltan campos requeridos: {campos}"}), 400

    conn = _conn()
    try:
        placeholders = ", ".join("?" for _ in campos)
        cur = conn.execute(
            f"INSERT INTO {nombre_tabla} ({', '.join(campos)}) VALUES ({placeholders})",
            valores,
        )
        conn.commit()
        return jsonify({"id": cur.lastrowid, **datos})
    finally:
        conn.close()


@app.post("/procesar")
def procesar():
    """
    Recibe una lista de rutas de PDF ya presentes en el sistema de archivos
    (la subida binaria en sí es un detalle de la interfaz gráfica, fuera del
    alcance de este backend mínimo) y las procesa de punta a punta hasta
    dejarlas en Pendiente_Validacion.
    """
    rutas = request.get_json(force=True).get("rutas", [])
    if not rutas:
        return jsonify({"error": "Debe indicar al menos una ruta"}), 400

    conn = _conn()
    try:
        resultado = {}
        for ruta in rutas:
            resultado[ruta] = procesar_archivo(conn, ruta)
        return jsonify({"procesados": resultado})
    finally:
        conn.close()


@app.get("/documentos")
def listar_documentos():
    """
    Lista el inventario para revisión. Por defecto muestra todo lo que aún
    no ha sido exportado (Recibido, En_Proceso, Pendiente_Validacion,
    Clasificado, Error) — un documento con error de OCR debe seguir siendo
    visible para que el usuario lo note, no desaparecer silenciosamente.
    """
    estado_proceso = request.args.get("estado_proceso")
    conn = _conn()
    try:
        base_query = """
            SELECT d.id, d.nombre_original, s.codigo AS sigla, d.especialidad_asunto,
                   e.nombre AS entidad, p.iniciales AS miembro, d.estado, d.estado_proceso
            FROM documentos d
            LEFT JOIN glosario_siglas s ON s.id = d.sigla_id
            LEFT JOIN glosario_entidades e ON e.id = d.entidad_id
            LEFT JOIN personas p ON p.id = d.miembro_id
        """
        if estado_proceso:
            filas = conn.execute(base_query + " WHERE d.estado_proceso = ? ORDER BY d.id", (estado_proceso,)).fetchall()
        else:
            filas = conn.execute(base_query + " WHERE d.estado_proceso != 'Exportado' ORDER BY d.id").fetchall()
        return jsonify([dict(f) for f in filas])
    finally:
        conn.close()


@app.get("/documentos/<int:documento_id>/paginas")
def ver_paginas(documento_id: int):
    """Detalle por página de un documento, para que el usuario vea qué se agrupó."""
    conn = _conn()
    try:
        filas = conn.execute(
            """
            SELECT numero_pagina, sigla_id, especialidad_asunto, entidad_id, miembro_id, resuelta
            FROM paginas WHERE documento_id = ? ORDER BY numero_pagina
            """,
            (documento_id,),
        ).fetchall()
        return jsonify([dict(f) for f in filas])
    finally:
        conn.close()


@app.post("/documentos/<int:documento_id>/confirmar")
def confirmar_documento(documento_id: int):
    """
    El usuario confirma (sin cambios) o corrige sigla/especialidad_asunto/
    entidad/miembro. Solo tras este paso el documento pasa a
    estado_proceso = 'Clasificado', habilitando la Fase 6.

    Si el documento queda resuelto (sigla + miembro), este mismo paso
    encadena automáticamente la nomenclatura (Fase 6) y el movimiento a
    Listos_para_importar (Fase 7/8): un solo clic del usuario completa todo
    el flujo restante, en vez de exigir pasos separados para cada fase
    técnica. Si el documento sigue sin resolver (NO_PROCESADO), se detiene
    aquí y queda visible para clasificación manual posterior.
    """
    conn = _conn()
    try:
        datos = request.get_json(force=True) or {}
        campos = ["sigla_id", "especialidad_asunto", "entidad_id", "miembro_id"]
        actualizaciones = {k: datos[k] for k in campos if k in datos}

        if actualizaciones:
            set_clause = ", ".join(f"{k} = ?" for k in actualizaciones)
            conn.execute(
                f"UPDATE documentos SET {set_clause}, estado_proceso = 'Clasificado' WHERE id = ?",
                (*actualizaciones.values(), documento_id),
            )
        else:
            conn.execute(
                "UPDATE documentos SET estado_proceso = 'Clasificado' WHERE id = ?",
                (documento_id,),
            )

        fila = conn.execute(
            "SELECT sigla_id, miembro_id FROM documentos WHERE id = ?", (documento_id,)
        ).fetchone()
        nuevo_estado = "OK" if fila and fila["sigla_id"] and fila["miembro_id"] else "NO_PROCESADO"
        conn.execute("UPDATE documentos SET estado = ? WHERE id = ?", (nuevo_estado, documento_id))

        conn.execute(
            "INSERT INTO log_operaciones (documento_id, accion, resultado, detalle) VALUES (?, 'confirmacion_usuario', ?, ?)",
            (documento_id, nuevo_estado, str(actualizaciones) or "sin cambios"),
        )
        conn.commit()

        respuesta = {"id": documento_id, "estado": nuevo_estado, "estado_proceso": "Clasificado"}

        if nuevo_estado == "OK":
            try:
                resultado_nombre = construir_nombre(conn, documento_id)
                guardar_nombre_propuesto(conn, resultado_nombre)
                ruta_final = mover_a_listos_para_importar(conn, documento_id, str(CARPETA_SALIDA))
                respuesta["nombre_final"] = resultado_nombre.nombre
                respuesta["ruta_final"] = ruta_final
                respuesta["estado_proceso"] = "Exportado"
            except (DatosIncompletos, OperacionFallida) as exc:
                respuesta["advertencia"] = str(exc)

        return jsonify(respuesta)
    finally:
        conn.close()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
