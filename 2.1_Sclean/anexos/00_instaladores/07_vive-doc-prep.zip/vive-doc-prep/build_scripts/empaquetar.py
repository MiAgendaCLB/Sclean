"""
Fase 10 — Empaquetado portable.

Construye la distribución final con PyInstaller e incluye explícitamente
los binarios externos que requiere OCRmyPDF (Tesseract, Ghostscript, qpdf),
resolviendo el riesgo ya identificado en la auditoría de arquitectura:
el empaquetado del código por sí solo NO incluye estos binarios.

IMPORTANTE — limitación real de PyInstaller (no de este script): PyInstaller
empaqueta para el sistema operativo en el que se ejecuta, no hace
compilación cruzada. Para generar el ejecutable de Windows, este script debe
correrse en una máquina Windows (o una VM/CI de Windows) con Tesseract,
Ghostscript y qpdf instalados en el PATH. Ejecutarlo en Linux produce un
binario de Linux, útil para probar que el empaquetado funciona, pero no es
el entregable final para el usuario.

Uso:
    python build_scripts/empaquetar.py
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DIST_DIR = PROJECT_ROOT / "dist" / "Sclean"

# Binarios que OCRmyPDF necesita en tiempo de ejecución. Ghostscript tiene
# nombres distintos según plataforma: en Windows es gswin64c/gswin32c, no
# "gs" (ese nombre solo existe en Linux/macOS).
BINARIOS_REQUERIDOS = {
    "tesseract": ["tesseract"],
    "ghostscript": ["gswin64c", "gswin32c", "gs"],
    "qpdf": ["qpdf"],
}


def _localizar_binario(nombres: list[str]) -> Path | None:
    for nombre in nombres:
        ruta = shutil.which(nombre)
        if ruta:
            return Path(ruta)
    return None


def _copiar_binarios(destino_bin: Path) -> list[str]:
    destino_bin.mkdir(parents=True, exist_ok=True)
    faltantes = []
    for etiqueta, nombres in BINARIOS_REQUERIDOS.items():
        ruta = _localizar_binario(nombres)
        if ruta is None:
            faltantes.append(etiqueta)
            continue
        shutil.copy2(ruta, destino_bin / ruta.name)
    return faltantes


def _copiar_tessdata(destino_tessdata: Path) -> str:
    """
    Copia los datos de idioma de Tesseract y sus subcarpetas de
    configuración (configs/, tessconfigs/). Copia TODO lo que exista, sin
    exigir que español esté presente como condición para copiar el resto
    (si el usuario no marcó el idioma español al instalar Tesseract, al
    menos se copian inglés y las configs, y se avisa explícitamente).
    Ubicaciones típicas: /usr/share/tesseract-ocr/*/tessdata (Linux),
    C:\\Program Files\\Tesseract-OCR\\tessdata (Windows).
    Devuelve: "ok" (con español), "sin_espanol" (copiado pero sin spa), o
    "no_encontrado" (no se halló ninguna carpeta tessdata).
    """
    posibles_origenes = list(Path("/usr/share").glob("tesseract-ocr/*/tessdata")) + [
        Path(r"C:\Program Files\Tesseract-OCR\tessdata"),
        Path(r"C:\Program Files (x86)\Tesseract-OCR\tessdata"),
    ]
    for origen in posibles_origenes:
        if not origen.exists():
            continue
        archivos_idioma = list(origen.glob("*.traineddata"))
        if not archivos_idioma:
            continue

        destino_tessdata.mkdir(parents=True, exist_ok=True)
        for archivo in archivos_idioma:
            shutil.copy2(archivo, destino_tessdata / archivo.name)
        for subcarpeta in ("configs", "tessconfigs"):
            origen_sub = origen / subcarpeta
            if origen_sub.exists():
                shutil.copytree(origen_sub, destino_tessdata / subcarpeta, dirs_exist_ok=True)

        return "ok" if (destino_tessdata / "spa.traineddata").exists() else "sin_espanol"

    return "no_encontrado"


def construir_ejecutable() -> None:
    comando = [
        sys.executable, "-m", "PyInstaller",
        "--name", "Sclean",
        "--onedir",  # --onedir, no --onefile: más fácil de inspeccionar/depurar la carpeta bin/ junto al ejecutable
        "--add-data", f"{PROJECT_ROOT / 'db' / 'schema.sql'}{_separador_add_data()}db",
        "--add-data", f"{PROJECT_ROOT / 'db' / 'seed_catalogos.sql'}{_separador_add_data()}db",
        "--add-data", f"{PROJECT_ROOT / 'db' / 'seed_reglas.sql'}{_separador_add_data()}db",
        # La interfaz gráfica (HTML/JS) no es código Python: PyInstaller no la
        # detecta por análisis estático de imports, hay que incluirla aparte.
        "--add-data", f"{PROJECT_ROOT / 'web' / 'static'}{_separador_add_data()}web/static",
        # ocrmypdf registra su motor Tesseract vía entry_points (metadatos del
        # paquete). Sin --collect-all, PyInstaller no incluye esos metadatos
        # y el motor OCR no se registra en tiempo de ejecución (falla con
        # "No OCR engine selected" aunque el binario tesseract sí exista).
        "--collect-all", "ocrmypdf",
        "--noconfirm",
        str(PROJECT_ROOT / "main.py"),
    ]
    subprocess.run(comando, check=True, cwd=PROJECT_ROOT)


def _separador_add_data() -> str:
    # PyInstaller usa ';' en Windows y ':' en Linux/macOS para --add-data.
    return ";" if sys.platform.startswith("win") else ":"


def main() -> None:
    print("Construyendo ejecutable con PyInstaller...")
    construir_ejecutable()

    print("Copiando binarios externos (Tesseract, Ghostscript, qpdf)...")
    faltantes = _copiar_binarios(DIST_DIR / "bin")
    if faltantes:
        print(
            f"ADVERTENCIA: no se encontraron en el PATH: {faltantes}. "
            f"Instálalos en esta máquina antes de empaquetar, o la distribución "
            f"resultante no podrá ejecutar OCR de forma portable."
        )

    print("Copiando datos de idioma de Tesseract (tessdata)...")
    resultado_tessdata = _copiar_tessdata(DIST_DIR / "tessdata")
    if resultado_tessdata == "no_encontrado":
        print("ADVERTENCIA: no se encontró ninguna carpeta tessdata. El OCR no funcionará en la distribución generada.")
    elif resultado_tessdata == "sin_espanol":
        print(
            "ADVERTENCIA: se copiaron datos de Tesseract pero falta 'spa.traineddata'. "
            "El OCR en español no funcionará. Reinstala Tesseract marcando el idioma "
            "español, o descarga spa.traineddata desde "
            "https://github.com/tesseract-ocr/tessdata y colócalo en la carpeta "
            "tessdata/ de Tesseract antes de volver a empaquetar."
        )

    print(f"\nListo. Distribución en: {DIST_DIR}")
    print("Copia toda esa carpeta al equipo destino; no requiere instalar Python, Tesseract ni Ghostscript por separado.")


if __name__ == "__main__":
    main()
