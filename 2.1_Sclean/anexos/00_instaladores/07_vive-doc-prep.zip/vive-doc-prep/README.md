# App de Preparación Documental — proyecto Vive

Aplicación local y portable para clasificar, restaurar (si aplica), nombrar y dejar listos
documentos escaneados, según la especificación funcional y la arquitectura técnica congeladas
del proyecto.

## Estado actual

- [x] Fase 0 — Esquema de base de datos y catálogos iniciales (verificado).
- [x] Fase 1 — Ingesta y extracción de texto (probado con los 4 PDFs reales de las pruebas de análisis).
- [x] Fase 2 — Motor de clasificación (probado; 11/22 páginas resueltas con reglas mínimas de 3 instituciones; el resto cae en NO_PROCESADO correctamente).
- [x] Fase 3 — Segmentación (probado; Oportunidad de Vida agrupa exactamente [1,2,3]=HC/[4]=OS/[5]=FM, igual que la clasificación manual del análisis. Límite conocido: una página sin marcador propio entre dos siglas distintas queda sin resolver, por diseño — no se adivina).
- [x] Fase 4 — Detección de duplicados (probado; hash exacto y similitud de contenido, sin falsos positivos entre documentos distintos. Bug corregido: sub-documentos de un mismo archivo de entrada ya no se marcan como duplicados entre sí).
- [x] Fase 5 — Orquestador (`core/pipeline.py`) + backend de confirmación humana (`web/server.py`), probado de punta a punta con `test_client` de Flask: procesar lote → listar pendientes → ver detalle por página → confirmar con corrección manual → confirmar sin cambios. Falta interfaz gráfica (HTML/JS); el backend ya es funcional.
- [x] Fase 6 — Nomenclatura (`core/naming.py`, `core/date_utils.py`). Probado con los 4 documentos reales: los 7 documentos resueltos generan exactamente los nombres validados manualmente en el análisis. Bugs reales encontrados y corregidos durante la prueba: (1) la fecha tomaba primero la fecha de nacimiento del paciente en vez de la fecha del documento — ahora prioriza etiquetas como "Fecha de la nota"; (2) la capitalización de entidad/especialidad dañaba los valores ya preprocesados de EM/CI — ahora solo re-capitaliza segmentos que aún tienen espacios (vienen de catálogo).
- [x] Fase 7 — Operación de archivo (`core/file_ops.py`). Idempotencia verificada explícitamente: dos ejecuciones seguidas del mismo lote producen 3 archivos, no 6. Bug real corregido: el chequeo de "ya existe" debía ir antes de exigir confirmación humana, o la propia idempotencia rompía en la segunda ejecución (el estado ya había cambiado a Exportado tras la primera).
- [x] Fase 8 — Marcado de estado final y carpeta de salida. Cumplida como parte de `file_ops.py`: al mover, el documento pasa a `estado=LISTO_PARA_IMPORTAR` / `estado_proceso=Exportado` y queda en la carpeta de salida real.
- [x] Fase 9 — Restauración condicional (`core/restoration.py`, opcional, no corre en el flujo principal). Probado con los 4 documentos reales: ninguno dispara restauración (nitidez muy por encima del umbral en las 22 páginas evaluadas), confirmando en la práctica que el módulo no interfiere con el flujo normal y solo se activaría ante un documento realmente degradado.
- [x] Fase 10 — Empaquetado portable (`build_scripts/empaquetar.py`, `main.py`). Verificado con una prueba de aislamiento total: ejecutable corriendo con `PATH` vacío y sin Python del sistema, procesando los 4 documentos reales de punta a punta (ingesta → OCR → clasificación → confirmación → nomenclatura → archivo final), con resultados idénticos a las pruebas de desarrollo.

  Bugs reales de empaquetado encontrados y corregidos durante la verificación (no evidentes hasta probar en aislamiento real, no solo revisar el código):
  1. `LD_LIBRARY_PATH` que PyInstaller fija hacia sus propias librerías internas interfiere con los binarios externos reales (tesseract/gs/qpdf) si no se maneja con cuidado.
  2. `ocrmypdf` registra su motor OCR vía metadatos de paquete (`entry_points`), que PyInstaller no incluye por defecto — requiere `--collect-all ocrmypdf` explícito.
  3. Las reglas de clasificación (`seed_reglas.sql`) nunca se cargaban en la base de datos del ejecutable empaquetado, solo los catálogos — corregido en `main.py` y en el build.
  4. Tesseract necesita también sus carpetas `configs/` y `tessconfigs/`, no solo los archivos `.traineddata` de idioma — sin ellas falla al generar PDF con texto embebido.
  5. Los binarios externos deben localizarse junto al ejecutable real (`Path(sys.executable).parent`), no en la carpeta interna de extracción de PyInstaller (`sys._MEIPASS`, distinta en modo `--onedir`).

  **Limitación real, no resuelta por diseño**: PyInstaller no hace compilación cruzada. Este proyecto se construyó y verificó en Linux; generar el ejecutable de Windows requiere correr `build_scripts/empaquetar.py` en una máquina Windows con Tesseract, Ghostscript y qpdf instalados (ver sección "Empaquetar para Windows" más abajo).
- [x] Interfaz gráfica (`web/static/index.html`, `web/static/app.js`). Responsiva (misma página sirve para PC y celular). El servidor escucha en `0.0.0.0`, no solo en `127.0.0.1`, para que el teléfono pueda acceder desde la misma red Wi-Fi usando la IP local que la app muestra al arrancar. Un solo clic en "Confirmar" encadena automáticamente nomenclatura y archivo final (Fases 6-8), no son pasos separados para el usuario. Verificado con subida real de PDF vía HTTP multipart (no solo con el cliente de pruebas de Flask), en el mismo entorno de aislamiento total ya usado para las demás pruebas.

  **Aviso de seguridad, no resuelto por diseño**: escuchar en `0.0.0.0` expone la app a cualquier dispositivo en la misma red Wi-Fi, no solo al teléfono del usuario. Dado que se manejan documentos médicos, esto es una decisión consciente para priorizar el acceso multi-dispositivo pedido, pero debe usarse en redes de confianza (casa), no en redes públicas.

## Cómo usar la app (PC o teléfono)

1. En el PC: ejecutar `Sclean.exe` (Windows) o `./Sclean` (Linux/prueba). Se abre el navegador automáticamente en `http://127.0.0.1:5000`.
2. La consola muestra también una segunda URL con la IP local (ej. `http://192.168.1.X:5000`) — esa es la que se escribe en el navegador del teléfono, estando conectado a la misma red Wi-Fi que el PC.
3. Desde cualquiera de los dos: elegir uno o varios PDF, tocar "Procesar", revisar la clasificación propuesta, corregir si hace falta (o usar "Otro" para dar de alta un valor nuevo de catálogo), y tocar "Confirmar" — ese único toque genera el nombre oficial y deja el archivo listo en `Listos_para_importar/`.

## Empaquetar para Windows

Este ejecutable se construyó y probó en Linux (limitación de PyInstaller: no compila para un sistema operativo distinto al que corre). Para generar la distribución de Windows:

1. En una máquina Windows, instalar Python 3.12+, Tesseract OCR (con el paquete de idioma español), Ghostscript y qpdf.
2. `pip install -r requirements.txt pyinstaller`
3. `python build_scripts\empaquetar.py`
4. La distribución queda en `dist\Sclean\`, con `bin\`, `tessdata\` y el ejecutable — se copia esa carpeta completa a cualquier equipo Windows sin instalar nada más.

Ver `plan_implementacion_mvp.md` (documento de planeación) para el detalle de cada fase.

## Hallazgos de prueba con documento real adicional (Clínica Nuestra Señora de los Remedios, 01/06/2026)

Se probó un quinto documento real, de una institución no vista antes (ya construido el `.exe` en Windows por el usuario), y se encontraron y corrigieron 2 bugs reales:

1. **Segmentación fusionaba 3 órdenes independientes con la HC anterior.** Las páginas de las órdenes (imagenología, interconsulta, cita de control) no decían literalmente "orden médica"/"orden externa", así que no tenían sigla propia y la herencia las fusionó con el documento HC precedente — justo el caso que la regla de "no adivinar" debía evitar. Corregido agregando una regla general de OS basada en el patrón estructural "Fecha y Hora de Solicitud" + "Consecutivo", presente en slips de orden de cualquier institución colombiana, no solo las ya vistas.
2. **La fecha extraía el nacimiento del paciente, no la del documento**, en instituciones que escriben "Fecha y hora de nacimiento (dd/mm/aaaa hh:mm): ..." — la exclusión anterior exigía que la fecha siguiera inmediatamente a la etiqueta, y fallaba con texto intermedio entre paréntesis. Corregido tolerando texto intermedio, y agregando "Fecha y Hora de Solicitud" como patrón de fecha documental prioritario.

Ambos verificados con el documento real y con regresión sobre los 4 documentos anteriores (sin cambios en su resultado ya validado).

## Bug crítico encontrado al probar el .exe real en Windows (versión 03 → 04)

Al ejecutar el `.exe` empaquetado en Windows y procesar un documento real de 5 páginas, la app generó correctamente 2 documentos con los nombres esperados (`..._HC_..._CLB.pdf` y `..._OS_..._CLB.pdf`), pero **ambos archivos contenían las 5 páginas completas**, no solo las que le correspondían a cada uno.

**Causa real**: la segmentación clasificaba correctamente los metadatos de cada grupo de páginas, pero la operación de mover/copiar el archivo final (`file_ops.py`) siempre copiaba el PDF de entrada completo (`ruta_original`), no un extracto con solo las páginas de ese grupo — nunca se generaba un PDF recortado de verdad.

**Corrección**: se agregó una columna `ruta_segmento` en `documentos`, y `core/pipeline.py` ahora extrae físicamente las páginas de cada grupo a un PDF nuevo (con `pikepdf`) inmediatamente después de la segmentación. `file_ops.py` copia ese PDF recortado, no el original completo.

Verificado con el mismo documento real: el archivo HC final quedó con 2 páginas, el archivo OS final con 3 páginas — coincide exactamente con las páginas de cada grupo.

## Bug adicional: entidad creada vía "Otro" no aparecía en otros documentos pendientes

Al confirmar el documento HC y crear una entidad nueva con "Otro", esa entidad no aparecía en el desplegable del documento OS del mismo evento (ya visible en pantalla) — obligando a crearla de nuevo y generando un duplicado en el catálogo.

**Causa**: `web/static/app.js` cargaba los catálogos una sola vez al abrir la página; crear una entrada nueva nunca refrescaba esa lista ni volvía a dibujar las tarjetas ya visibles.

**Corrección**: tras crear cualquier entrada nueva vía "Otro" (sigla, entidad o persona), la interfaz ahora recarga los catálogos y vuelve a dibujar toda la lista de pendientes, para que la entrada nueva esté disponible de inmediato en cualquier documento, no solo en el que se estaba confirmando.

## Bug adicional: la interfaz no tenía forma de indicar la especialidad

Para instituciones sin reglas propias (como una recién creada vía "Otro"), el campo "especialidad o asunto" quedaba siempre vacío en el nombre final — no porque el motor de clasificación fallara, sino porque **la interfaz nunca mostraba un campo para escribirlo o elegirlo**. Solo existían selects para sigla, miembro y entidad.

**Corrección**: se agregó un select de "Especialidad o asunto" en cada tarjeta de confirmación, con las especialidades ya cargadas en el catálogo y la opción "Otro" para escribir una nueva (que además se guarda en el catálogo para reutilizarla después). Verificado de punta a punta: el nombre final ahora sí incluye la especialidad (`20260601_HC_Neurocirugia_CLB.pdf`).

## Corrección: la especialidad debía detectarse sola, no elegirse a mano

El select manual resolvía el síntoma pero no la causa: entidad y miembro ya se detectaban automáticamente buscando el catálogo directamente en el texto (sin depender de una regla propia por institución), pero especialidad se había quedado dependiendo únicamente de reglas por institución o de selección manual.

**Corrección real**: se agregó `_detectar_especialidad()` en `core/classification/engine.py`, con el mismo mecanismo genérico ya usado para entidad y miembro — busca cada especialidad ya cargada en el catálogo directamente en el texto, sin necesitar una regla por institución. Se ejecuta solo si ninguna regla (general o de institución) ya dio un valor más específico, y no aplica a CI/EM (que usan su propio valor extraído). También se corrigió la comparación para ignorar tildes (el texto real suele venir en mayúsculas sin acentos, ej. "NEUROCIRUGIA" vs. catálogo "Neurocirugía").

Verificado con el mismo documento real, confirmando sin escribir nada manual: `20260601_HC_Neurocirugía_CLB.pdf` — especialidad detectada sola. Sin regresión sobre los documentos ya validados.

## Corrección: eliminar tildes/diacríticos del nombre final

Se centralizó en `core/naming.py` (`_limpiar_segmento`) la eliminación de tildes para evitar problemas de compatibilidad entre sistemas de archivos, sin importar de dónde venga el valor (catálogo, regla de institución, detección automática o corrección manual). Verificado con los 5 documentos reales: `Neurocirugia`, `Psiquiatria`, `Neurologia` — ya sin tildes en ningún caso.

## Correcciones de interfaz: drag-and-drop, acumulación de archivos, detección de entidad/miembro

1. **Arrastrar y soltar PDFs**: se agregó soporte de drag-and-drop sobre la zona de subida (antes solo se podía elegir por el explorador de archivos).
2. **Los archivos no se acumulaban al elegir de carpetas distintas**: el `<input type=file>` reemplaza su selección cada vez que se usa (comportamiento nativo del navegador) — antes esto vaciaba lo ya elegido. Corregido manteniendo una lista propia en JS que acumula archivos entre selecciones (y entre arrastrar/soltar), en vez de depender directamente de `input.files`.
3. **Entidad y miembro no se detectaban en documentos con tildes ausentes en el texto** (ej. "CLINICA IMBANACO" sin tilde en un documento nativo, vs. catálogo "Clínica Imbanaco" con tilde) — mismo tipo de bug ya corregido antes para especialidad, ahora aplicado también a `_detectar_entidad` y `_detectar_miembro`. Verificado con `Patologia_1.pdf`: antes no detectaba ni entidad ni sigla; ahora detecta entidad y miembro correctamente (sigue sin sigla, ver nota abajo).

## Hallazgo de dominio pendiente de decisión: no existe sigla para "Informe de Resultados"

Se probó un documento de anatomía patológica (`Patologia_1.pdf`, PDF nativo de Clínica Imbanaco, sin necesidad de OCR). El catálogo de siglas (HC, OS, FM, IS, CI, EM) no cubre el **resultado** de un estudio de laboratorio/patología — solo cubre la **orden** (OS). No se inventó una sigla nueva sin confirmación; queda pendiente definir si es una sigla propia (ej. "RE" de Resultado) o si se integra a OS bajo otro criterio.

## Limitación conocida, no resuelta: OCR de logo degradado (ImbanacoTitoides.pdf)

En documentos escaneados donde el logo de la institución se lee mal por OCR (ej. "Imbanaco" reconocido como "m b a n a c o", con espacios sueltos entre letras), la detección de entidad sigue sin funcionar — esto no es un bug de comparación de texto, es una limitación real de calidad de OCR sobre esa imagen específica. Queda como corrección manual del usuario (ya soportado por el select de entidad en la interfaz).

## Puesta en marcha (desarrollo)

```bash
pip install -r requirements.txt
python db/init_db.py --with-seed
```

Esto crea `data/vive_docs.db` con el esquema y los catálogos ya validados con los
documentos de prueba usados durante el análisis (Clínica Imbanaco, Oportunidad de Vida,
Neurólogos de Occidente, SOS EPS; siglas HC/OS/FM/IS/CI/EM; personas CLB/YHM/OLF).

## Estructura

```
core/
  ingest.py                → Fase 1
  text_extraction.py       → Fase 1
  ocr.py                   → Fase 1
  classification/
    engine.py               → Fase 2
    rules_repository.py     → Fase 2
  segmentation.py           → Fase 3
  duplicates.py             → Fase 4
  naming.py                 → Fase 6
  file_ops.py                → Fase 7
  restoration.py             → Fase 9 (opcional)
db/
  schema.sql                 → esquema de base de datos
  seed_catalogos.sql          → datos iniciales ya validados
  init_db.py                  → inicialización
web/                          → interfaz de confirmación (Fase 5)
data/                         → base de datos y logs (no versionar)
salida/
  Listos_para_importar/       → documentos terminados (LISTO_PARA_IMPORTAR)
  No_procesados/               → documentos que no se pudieron clasificar
  originales/                   → copia intacta de los PDFs de entrada
```

## Reglas que no deben romperse durante el desarrollo

- Ningún documento se renombra sin pasar por confirmación humana (Fase 5 antes que Fase 6).
- Toda operación de archivo es idempotente y queda registrada en `log_operaciones`.
- El borrado siempre corre primero en modo prueba (dry-run).
- La restauración de imagen no se aplica a páginas que ya tengan buena calidad.

## Corrección de fondo: normalización de texto centralizada (tildes + espacios en blanco)

Los parches anteriores de tildes (especialidad, luego entidad/miembro) quedaban dispersos y repetidos en cada función. Se centralizó en `core/text_utils.py` (`normalizar()`), usado ahora en **todas** las comparaciones de texto del motor: reglas de sigla, entidad, miembro y especialidad — no solo donde se habían reportado bugs puntuales.

Al revisar a fondo se encontró un segundo problema de la misma familia: el texto extraído de un PDF puede partir en líneas distintas palabras que en el catálogo van juntas (ej. "Clínica\nImbanaco" en vez de "Clínica Imbanaco"). Una comparación exacta con espacio literal fallaba aunque la palabra estuviera perfectamente legible — esto también afectaba a los patrones de sigla (ej. "HISTORIA CL[IÍ]NICA" exige un espacio literal entre palabras). `normalizar()` ahora colapsa cualquier espacio en blanco (saltos de línea, tabs, espacios múltiples) a uno solo, además de quitar tildes.

Se preservó el texto original (sin normalizar) para la extracción de valores de CI/EM, que sí dependen de la estructura de líneas real del documento (ej. aislar el asunto de un correo antes del salto de línea "N mensaje").

Verificado con los 6 documentos reales: sin regresión en los 5 ya validados, y la entidad de `ImbanacoTitoides.pdf` (antes nunca detectada) ahora sí se reconoce en al menos una de sus páginas.

## Siglas nuevas agregadas: EP (Epicrisis) y OPS (Autorización)

De la lista de siglas comunes propuesta, se confirmaron y agregaron solo estas dos:

- **EP** — Epicrisis (resumen de egreso hospitalario). Regla general: detecta el texto "EPICRISIS".
- **OPS** — Autorización (de servicios/procedimientos por la aseguradora). Regla general: detecta "AUTORIZACION" (con o sin tilde, ya normalizado).

Probadas con texto sintético representativo (no había documento real de estos tipos disponible todavía): ambas siglas se detectan correctamente. Regresión completa sobre los 6 documentos reales ya validados: sin cambios en su resultado.

## Sigla adicional: RE (Resultado)

Se agregó también **RE** (resultado de laboratorio, patología o imágenes), distinta de OS (que es la orden que solicita el estudio, no su resultado). Regla general: detecta "INFORME DE RESULTADOS", "RESULTADO DE LABORATORIO" o "INFORME DE PATOLOGIA". Probada con el documento real `Patologia_1.pdf`: `20250929_RE_ClinicaImbanaco_YHM.pdf` — correcto. Sin regresión sobre el resto.

## Aclaración importante: por qué la app no logra lo mismo que la clasificación manual hecha en el chat

En partes de esta conversación, Claude clasificó documentos manualmente leyendo directamente las imágenes del PDF (visión), incluso cuando el logo estaba mal escaneado. La app empaquetada **no tiene ese recurso**: solo usa Tesseract (OCR de texto), sin ningún modelo de lenguaje/visión en el flujo principal — esto fue una decisión de arquitectura ya tomada explícitamente (mantener la app 100% local, sin depender de internet ni de una IA para funcionar). Por eso, en un documento donde el logo se escaneó realmente mal (ej. "Imbanaco" ilegible en 3 de 4 páginas), la app puede quedar por debajo de lo que Claude logra manualmente — no es un defecto de la app, es la diferencia entre un motor de reglas determinista y una lectura visual asistida por IA, y esa diferencia fue una decisión consciente, no un descuido.
