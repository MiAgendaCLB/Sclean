"""
Punto de entrada de la aplicación empaquetada.

Arranca el servidor Flask en localhost y abre el navegador automáticamente,
tal como especifica la arquitectura técnica ("arranca servidor local + abre
navegador"). Es lo que ejecuta el .exe/binario final generado por PyInstaller.
"""

from __future__ import annotations

import os
import sys
import threading
import time
import webbrowser
from pathlib import Path


def _ruta_base() -> Path:
    """
    Cuando corre empaquetado por PyInstaller, los archivos van dentro de
    sys._MEIPASS (carpeta temporal de extracción). En desarrollo, es
    simplemente la carpeta del proyecto.
    """
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent


def _ruta_datos_usuario() -> Path:
    """
    La base de datos y los logs deben vivir junto al ejecutable, no dentro
    de la carpeta temporal de PyInstaller (que se borra entre ejecuciones).
    Portabilidad real: si el usuario copia la carpeta de distribución a otro
    equipo, sus datos van con ella.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "data"
    return Path(__file__).resolve().parent / "data"


def _ruta_ejecutable() -> Path:
    """
    Carpeta donde vive el ejecutable final (dist/Sclean), distinta de
    _ruta_base(): PyInstaller en modo --onedir extrae los datos empaquetados
    (schema.sql, etc.) dentro de una carpeta interna (_internal, apuntada
    por sys._MEIPASS), pero los binarios externos que este proyecto agrega
    aparte (bin/, tessdata/, ver build_scripts/empaquetar.py) se colocan
    junto al ejecutable, un nivel por encima de esa carpeta interna.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _asegurar_binarios_en_path() -> None:
    """
    Si el paquete incluye Tesseract/Ghostscript/qpdf embebidos (ver
    build/empaquetar.py), esta función los antepone al PATH para que
    OCRmyPDF los encuentre sin que el usuario tenga que instalarlos.
    """
    base = _ruta_ejecutable()
    carpeta_binarios = base / "bin"
    if carpeta_binarios.exists():
        os.environ["PATH"] = str(carpeta_binarios) + os.pathsep + os.environ.get("PATH", "")
    carpeta_tessdata = base / "tessdata"
    if carpeta_tessdata.exists():
        os.environ["TESSDATA_PREFIX"] = str(carpeta_tessdata)


def _inicializar_base_datos_si_hace_falta(ruta_datos: Path) -> Path:
    ruta_db = ruta_datos / "vive_docs.db"
    os.environ["VIVE_DB_PATH"] = str(ruta_db)
    if ruta_db.exists():
        return ruta_db

    sys.path.insert(0, str(_ruta_base()))
    from db.init_db import init_db  # import diferido: necesita el path ya resuelto

    ruta_creada = init_db(with_seed=True, ruta_db=ruta_db)

    # init_db solo carga catálogos (seed_catalogos.sql). Las reglas de
    # clasificación (seed_reglas.sql) se cargan aparte: no forman parte del
    # esquema base ni de los catálogos, son datos de configuración propios
    # de este proyecto de prueba.
    import sqlite3
    ruta_reglas = _ruta_base() / "db" / "seed_reglas.sql"
    if ruta_reglas.exists():
        conn = sqlite3.connect(ruta_creada)
        try:
            conn.executescript(ruta_reglas.read_text(encoding="utf-8"))
            conn.commit()
        finally:
            conn.close()

    return ruta_creada


def _obtener_ip_local() -> str | None:
    """
    IP de este equipo en la red local (Wi-Fi/LAN), para que el teléfono
    pueda escribirla en su navegador. Si no hay red disponible, devuelve
    None y solo queda accesible desde este mismo equipo.
    """
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def main() -> None:
    _asegurar_binarios_en_path()
    ruta_ejecutable = _ruta_ejecutable()
    ruta_datos = _ruta_datos_usuario()
    _inicializar_base_datos_si_hace_falta(ruta_datos)

    # Coherente con la base de datos: subidos y salida también viven junto al
    # ejecutable real, no dentro de la carpeta interna de PyInstaller
    # (server.py ya sabía leer estas variables, pero nunca se fijaban).
    os.environ["VIVE_UPLOADS_PATH"] = str(ruta_datos / "subidos")
    os.environ["VIVE_SALIDA_PATH"] = str(ruta_ejecutable / "Listos_para_importar")

    sys.path.insert(0, str(_ruta_base()))
    from web.server import app

    puerto = 5000
    hilo = threading.Thread(
        target=lambda: app.run(host="0.0.0.0", port=puerto, use_reloader=False), daemon=True
    )
    hilo.start()

    time.sleep(1.0)  # margen para que el servidor levante antes de abrir el navegador
    webbrowser.open(f"http://127.0.0.1:{puerto}")

    ip_local = _obtener_ip_local()
    print(f"\nSclean corriendo.")
    print(f"  En este equipo:        http://127.0.0.1:{puerto}")
    if ip_local:
        print(f"  Desde el teléfono (misma red Wi-Fi): http://{ip_local}:{puerto}")
    else:
        print(f"  (No se detectó red local; solo accesible desde este equipo.)")
    print("\nCierra esta ventana para salir.")
    hilo.join()


if __name__ == "__main__":
    main()
