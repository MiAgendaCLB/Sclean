-- Datos iniciales — solo lo ya confirmado con documentos reales durante el análisis.
-- No se inventan instituciones, especialidades ni siglas adicionales.

-- Siglas (catálogo cerrado en la especificación funcional)
INSERT INTO glosario_siglas (codigo, nombre) VALUES
  ('HC', 'Historia Clínica'),
  ('OS', 'Orden de Servicio'),
  ('FM', 'Fórmula Médica'),
  ('IS', 'Insumos'),
  ('CI', 'Incapacidad Médica'),
  ('EM', 'Correspondencia / Comunicaciones'),
  ('EP', 'Epicrisis'),
  ('OPS', 'Autorización'),
  ('RE', 'Resultado');

-- Personas (grupo familiar ya mencionado: CLB, YHM, OLF)
INSERT INTO personas (iniciales, nombre_completo) VALUES
  ('CLB', 'Christian Lemos Benitez'),
  ('YHM', 'Yamileth Hurtado Montaño'),
  ('OLF', NULL);

-- Entidades vistas en las pruebas (tipo 'prestador' = institución; 'aseguradora' = EPS)
INSERT INTO glosario_entidades (nombre, tipo) VALUES
  ('Clínica Imbanaco', 'prestador'),
  ('Oportunidad de Vida', 'prestador'),
  ('Neurólogos de Occidente', 'prestador'),
  ('SOS EPS', 'aseguradora');

-- Especialidades vistas en las pruebas
INSERT INTO glosario_especialidades (nombre) VALUES
  ('Cirugía Oncológica'),
  ('Medicina Nuclear'),
  ('Endocrinología'),
  ('Psiquiatría'),
  ('Neurología'),
  ('Hematología'),
  ('Neurocirugía');
