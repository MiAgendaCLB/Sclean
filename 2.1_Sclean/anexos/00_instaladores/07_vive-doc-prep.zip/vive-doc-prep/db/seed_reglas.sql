-- Reglas de clasificación — solo las validadas contra los documentos reales
-- usados durante el análisis. No se inventan reglas para instituciones no vistas.

-- =========================================================
-- Reglas generales (entidad_id NULL) — identifican la sigla por el texto típico
-- de cada tipo documental, independientemente de la institución.
-- =========================================================

INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'HISTORIA CL[IÍ]NICA', id, 'catalogo', NULL, NULL, 10 FROM glosario_siglas WHERE codigo = 'HC';

INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'ORDENES? EXTERNAS?|ORDEN DE SERVICIO|ORDEN M[EÉ]DICA|ORDEN DE CONTROL', id, 'catalogo', NULL, NULL, 20 FROM glosario_siglas WHERE codigo = 'OS';

-- Slips de orden individuales (imagenología, interconsultas, citas de control,
-- etc.) no siempre dicen literalmente "orden médica"/"orden externa" — pero
-- casi todas las instituciones colombianas marcan cada slip con un número de
-- "Consecutivo" propio junto a "Fecha y Hora de Solicitud". Esta es una señal
-- estructural más confiable que el texto libre del encabezado, y evita que
-- estas páginas queden sin sigla y se fusionen por herencia con el documento
-- HC anterior (hallazgo real: 3 slips de orden distintos fusionados con la
-- HC precedente por falta de esta regla).
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'Fecha y Hora de Solicitud|Consecutivo:?\s*[A-Za-z]{0,4}-?\d{4,}', id, 'catalogo', NULL, NULL, 22 FROM glosario_siglas WHERE codigo = 'OS';

INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'RECETA M[EÉ]DICA|SOLICITUD DE MEDICAMENTOS', id, 'catalogo', NULL, NULL, 30 FROM glosario_siglas WHERE codigo = 'FM';

INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'INCAPACIDAD M[EÉ]DICA', id, 'extraido', NULL, 'Inicio de incapacidad\s*(\d{4}-\d{2}-\d{2}).*?Fin de incapacidad\s*(\d{4}-\d{2}-\d{2})', 40 FROM glosario_siglas WHERE codigo = 'CI';

INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, '\d+\s*mensaje', id, 'extraido', NULL, '([^\n]+)\s*\n\d+\s*mensaje', 50 FROM glosario_siglas WHERE codigo = 'EM';

-- Epicrisis: resumen de egreso hospitalario, término estándar en Colombia
-- que aparece como título propio del documento.
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'EPICRISIS', id, 'catalogo', NULL, NULL, 25 FROM glosario_siglas WHERE codigo = 'EP';

-- Autorización de servicios/procedimientos por parte de la aseguradora.
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'AUTORIZACION( DE SERVICIOS)?', id, 'catalogo', NULL, NULL, 25 FROM glosario_siglas WHERE codigo = 'OPS';

-- Resultado de laboratorio, patología o imágenes ya realizadas (distinto de
-- la orden que las solicitó, ver OS).
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT NULL, 'INFORME DE RESULTADOS|RESULTADO DE LABORATORIO|INFORME DE PATOLOGIA', id, 'catalogo', NULL, NULL, 25 FROM glosario_siglas WHERE codigo = 'RE';

-- =========================================================
-- Reglas por institución — refinan especialidad/asunto cuando el formato
-- de esa institución lo permite. Solo se cargan las ya vistas en pruebas.
-- =========================================================

-- Imbanaco: la especialidad aparece como "Especialidad: <NOMBRE>" en el bloque de firma
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT e.id, 'CONSULTA EXTERNA', s.id, 'extraido', NULL, 'Especialidad:\s*([A-ZÁÉÍÓÚÑ ]+)', 15
FROM glosario_entidades e, glosario_siglas s
WHERE e.nombre = 'Clínica Imbanaco' AND s.codigo = 'OS';

-- Oportunidad de Vida: la especialidad aparece como "Esp: <NOMBRE>" tras el nombre del médico
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT e.id, 'HISTORIA CL[IÍ]NICA', s.id, 'extraido', NULL, 'Esp:\s*([A-ZÁÉÍÓÚÑ ]+)', 15
FROM glosario_entidades e, glosario_siglas s
WHERE e.nombre = 'Oportunidad de Vida' AND s.codigo = 'HC';

-- Neurólogos de Occidente: la especialidad aparece en el título "HISTORIA CLINICA DE <ESPECIALIDAD>"
INSERT INTO reglas_clasificacion (entidad_id, patron_texto, sigla_id, modo_especialidad_asunto, especialidad_id, patron_extraccion, prioridad)
SELECT e.id, 'HISTORIA CL[IÍ]NICA DE', s.id, 'extraido', NULL, 'HISTORIA CL[IÍ]NICA DE\s+([A-ZÁÉÍÓÚÑ]+)', 15
FROM glosario_entidades e, glosario_siglas s
WHERE e.nombre = 'Neurólogos de Occidente' AND s.codigo = 'HC';
