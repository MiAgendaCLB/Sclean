-- Esquema de base de datos — App de Preparación Documental (proyecto Vive)
-- Corresponde exactamente al modelo de datos definido en arquitectura_tecnica_mvp.md
-- No modificar sin actualizar primero el documento de arquitectura.

PRAGMA foreign_keys = ON;

-- =========================================================
-- Catálogos (Glosario) — todos editables, con soporte "Otro -> crear nuevo"
-- =========================================================

CREATE TABLE glosario_siglas (
  id INTEGER PRIMARY KEY,
  codigo TEXT UNIQUE NOT NULL,       -- HC, OS, FM, IS, CI, EM, ...
  nombre TEXT NOT NULL,
  activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE glosario_especialidades (
  id INTEGER PRIMARY KEY,
  nombre TEXT NOT NULL,
  activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE glosario_entidades (
  id INTEGER PRIMARY KEY,
  nombre TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK(tipo IN ('prestador','aseguradora')),
  activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE personas (
  id INTEGER PRIMARY KEY,
  iniciales TEXT UNIQUE NOT NULL,     -- CLB, YHM, OLF, ...
  nombre_completo TEXT,
  activo INTEGER NOT NULL DEFAULT 1
);

-- =========================================================
-- Motor de reglas de clasificación
-- Una sola tabla: entidad_id NULL = regla general, entidad_id definido = regla por institución
-- modo_especialidad_asunto distingue si el valor viene de catálogo o se extrae del texto (CI, EM)
-- =========================================================

CREATE TABLE reglas_clasificacion (
  id INTEGER PRIMARY KEY,
  entidad_id INTEGER REFERENCES glosario_entidades(id),
  patron_texto TEXT NOT NULL,
  sigla_id INTEGER NOT NULL REFERENCES glosario_siglas(id),
  modo_especialidad_asunto TEXT NOT NULL DEFAULT 'catalogo'
      CHECK(modo_especialidad_asunto IN ('catalogo','extraido')),
  especialidad_id INTEGER REFERENCES glosario_especialidades(id),
  patron_extraccion TEXT,
  prioridad INTEGER NOT NULL DEFAULT 100,
  activo INTEGER NOT NULL DEFAULT 1
);

-- =========================================================
-- Agrupación por evento (regla mínima MVP: misma fecha + misma entidad + mismo miembro)
-- =========================================================

CREATE TABLE eventos (
  id INTEGER PRIMARY KEY,
  fecha TEXT NOT NULL,
  entidad_id INTEGER REFERENCES glosario_entidades(id),
  miembro_id INTEGER REFERENCES personas(id)
);

-- =========================================================
-- Registro central de documentos
-- =========================================================

CREATE TABLE documentos (
  id INTEGER PRIMARY KEY,
  hash TEXT,
  ruta_original TEXT NOT NULL,
  nombre_original TEXT NOT NULL,
  ruta_actual TEXT,
  nombre_propuesto TEXT,
  fecha_documental TEXT,
  sigla_id INTEGER REFERENCES glosario_siglas(id),
  especialidad_asunto TEXT,
  entidad_id INTEGER REFERENCES glosario_entidades(id),
  miembro_id INTEGER REFERENCES personas(id),
  evento_id INTEGER REFERENCES eventos(id),
  texto_extraido TEXT,  -- texto OCR/nativo concatenado del documento; necesario para comparar duplicados por contenido entre sesiones
  ruta_segmento TEXT,  -- PDF extraído con solo las páginas de este grupo (distinto del original completo); lo que realmente se copia a Listos_para_importar
  estado TEXT NOT NULL CHECK(
    estado IN ('OK','RENOMBRAR','DUPLICADO','NO_PROCESADO','LISTO_PARA_IMPORTAR')
  ),
  estado_proceso TEXT NOT NULL DEFAULT 'Recibido' CHECK(
    estado_proceso IN ('Recibido','En_Proceso','Pendiente_Validacion','Clasificado','Exportado','Error')
  ),  -- complementario a `estado`: ciclo de vida del procesamiento, no el resultado de clasificación
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT
);

-- Clasificación propuesta por página, previa a la confirmación del usuario (Fase 5).
-- Necesaria porque el procesamiento del backend y la confirmación ocurren en pasos
-- separados (con una recarga de interfaz de por medio).
CREATE TABLE paginas (
  id INTEGER PRIMARY KEY,
  documento_id INTEGER NOT NULL REFERENCES documentos(id),
  numero_pagina INTEGER NOT NULL,
  sigla_id INTEGER REFERENCES glosario_siglas(id),
  especialidad_asunto TEXT,
  entidad_id INTEGER REFERENCES glosario_entidades(id),
  miembro_id INTEGER REFERENCES personas(id),
  resuelta INTEGER NOT NULL DEFAULT 0,
  UNIQUE(documento_id, numero_pagina)
);

CREATE TABLE duplicados (
  id INTEGER PRIMARY KEY,
  documento_id INTEGER NOT NULL REFERENCES documentos(id),
  documento_oficial_id INTEGER NOT NULL REFERENCES documentos(id),
  tipo_deteccion TEXT NOT NULL CHECK(tipo_deteccion IN ('hash','contenido'))
);

CREATE TABLE log_operaciones (
  id INTEGER PRIMARY KEY,
  documento_id INTEGER REFERENCES documentos(id),
  accion TEXT NOT NULL,               -- 'movido','ya_existia','error','ocr','clasificado', ...
  resultado TEXT NOT NULL,
  detalle TEXT,
  timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
-- Índices de apoyo (no cambian el modelo, solo aceleran lecturas frecuentes)
-- =========================================================

CREATE INDEX idx_documentos_estado ON documentos(estado);
CREATE INDEX idx_documentos_hash ON documentos(hash);
CREATE INDEX idx_reglas_entidad ON reglas_clasificacion(entidad_id);
CREATE INDEX idx_log_documento ON log_operaciones(documento_id);
