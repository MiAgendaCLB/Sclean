"""
Inicializa la base de datos SQLite del proyecto a partir de db/schema.sql
y, opcionalmente, precarga los catálogos ya validados (db/seed_catalogos.sql).

Uso:
    python db/init_db.py                # crea el esquema en data/vive_docs.db
    python db/init_db.py --with-seed    # además precarga catálogos

La ruta de destino es configurable (necesario para el ejecutable empaquetado,
que coloca la base de datos junto al binario, no dentro de la carpeta
temporal de extracción de PyInstaller).
"""

import sqlite3
import sys
from pathlib import Path

DB_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = DB_DIR.parent
SCHEMA_PATH = DB_DIR / "schema.sql"
SEED_PATH = DB_DIR / "seed_catalogos.sql"


def init_db(with_seed: bool = False, ruta_db: Path | None = None) -> Path:
    ruta_db = ruta_db or (PROJECT_ROOT / "data" / "vive_docs.db")
    ruta_db.parent.mkdir(parents=True, exist_ok=True)

    if ruta_db.exists():
        raise SystemExit(
            f"Ya existe una base de datos en {ruta_db}. "
            f"Elimínala manualmente si quieres recrearla desde cero."
        )

    conn = sqlite3.connect(ruta_db)
    try:
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        if with_seed:
            conn.executescript(SEED_PATH.read_text(encoding="utf-8"))
        conn.commit()
    finally:
        conn.close()

    print(f"Base de datos creada en: {ruta_db}")
    if with_seed:
        print("Catálogos iniciales precargados.")
    return ruta_db


if __name__ == "__main__":
    init_db(with_seed="--with-seed" in sys.argv)
